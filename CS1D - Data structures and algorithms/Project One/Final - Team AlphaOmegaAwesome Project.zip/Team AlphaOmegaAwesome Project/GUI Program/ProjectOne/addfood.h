#ifndef ADDFOOD_H
#define ADDFOOD_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include <QLineEdit>
#include <QDoubleValidator>
#include <QRegExpValidator>
#include "noinput.h"

namespace Ui {
class AddFood;
}

class AddFood : public QDialog
{
    Q_OBJECT

public:
    /// Adds an item to to the specified city using a database query
    void Add();

    /// Initiates the combobox( drop down menu )
    ///      Sets labels  acoording to cities in the database
    void SetupComboBox(Ui::AddFood *ui);

    /// Loads and displays the food_costs database to the tableView
    void LoadFoodCostDatabase();

    /// Default Constructor
    explicit AddFood(QWidget *parent = 0);

    /// Default destructor
    ~AddFood();

private slots:
    void on_Save_Button_clicked();

    void on_Done_Button_clicked();

    void on_Go_Button_clicked();

    void on_comboBox_activated(const QString &arg1);

    void on_FoodCost_Line_textEdited(const QString &arg1);

    void on_FoodItem_Line_textEdited(const QString &arg1);

private:
    Ui::AddFood *ui;
};

#endif /// ADDFOOD_H
