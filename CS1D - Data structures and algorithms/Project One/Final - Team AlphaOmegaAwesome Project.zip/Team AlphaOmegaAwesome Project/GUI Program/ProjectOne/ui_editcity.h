/********************************************************************************
** Form generated from reading UI file 'editcity.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITCITY_H
#define UI_EDITCITY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_EditCity
{
public:
    QDialogButtonBox *buttonBox;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLabel *label_2;
    QLabel *label_3;
    QTableView *tableView;

    void setupUi(QDialog *EditCity)
    {
        if (EditCity->objectName().isEmpty())
            EditCity->setObjectName(QStringLiteral("EditCity"));
        EditCity->resize(514, 480);
        buttonBox = new QDialogButtonBox(EditCity);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(410, 410, 81, 241));
        buttonBox->setOrientation(Qt::Vertical);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        lineEdit_2 = new QLineEdit(EditCity);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(30, 50, 351, 31));
        lineEdit_3 = new QLineEdit(EditCity);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(30, 110, 351, 31));
        label_2 = new QLabel(EditCity);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 20, 91, 21));
        label_3 = new QLabel(EditCity);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(30, 80, 91, 21));
        tableView = new QTableView(EditCity);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 160, 351, 301));

        retranslateUi(EditCity);
        QObject::connect(buttonBox, SIGNAL(accepted()), EditCity, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), EditCity, SLOT(reject()));

        QMetaObject::connectSlotsByName(EditCity);
    } // setupUi

    void retranslateUi(QDialog *EditCity)
    {
        EditCity->setWindowTitle(QApplication::translate("EditCity", "Dialog", 0));
        label_2->setText(QApplication::translate("EditCity", "Food Item:", 0));
        label_3->setText(QApplication::translate("EditCity", "New Food Cost: ", 0));
    } // retranslateUi

};

namespace Ui {
    class EditCity: public Ui_EditCity {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITCITY_H
