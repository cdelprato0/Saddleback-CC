/********************************************************************************
** Form generated from reading UI file 'reciept.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECIEPT_H
#define UI_RECIEPT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Reciept
{
public:
    QTextEdit *textEdit;

    void setupUi(QDialog *Reciept)
    {
        if (Reciept->objectName().isEmpty())
            Reciept->setObjectName(QStringLiteral("Reciept"));
        Reciept->resize(430, 680);
        textEdit = new QTextEdit(Reciept);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(0, 0, 431, 681));
        QFont font;
        font.setPointSize(9);
        font.setBold(true);
        font.setWeight(75);
        textEdit->setFont(font);
        textEdit->setReadOnly(true);

        retranslateUi(Reciept);

        QMetaObject::connectSlotsByName(Reciept);
    } // setupUi

    void retranslateUi(QDialog *Reciept)
    {
        Reciept->setWindowTitle(QApplication::translate("Reciept", "Trip Reciept", 0));
    } // retranslateUi

};

namespace Ui {
    class Reciept: public Ui_Reciept {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECIEPT_H
