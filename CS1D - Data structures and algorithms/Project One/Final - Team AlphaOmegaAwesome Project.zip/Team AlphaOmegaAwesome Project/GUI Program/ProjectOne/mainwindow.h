#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "visitallcities.h"
#include "customtrip.h"
#include "shortesttrip.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /// Default Constructor
    explicit MainWindow(QWidget *parent = 0);

    /// Default Destructor
    ~MainWindow();

    /// Setups the Main Window
    void SetupWindow(Ui::MainWindow *ui);

    /// This Function will load both databases and
    ///  display them to the tableView widget on the GUI
    void LoadDatabase(Ui::MainWindow *ui);

    /// Sets the city names in the drop down menu from the database
    void SetupComboBox(Ui::MainWindow *ui);
private slots:
    void on_actionLogin_triggered();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::MainWindow *ui;
    VisitAllCities vac;
    CustomTrip cust;
    ShortestTrip shrt;
};

#endif /// MAINWINDOW_H
