#include "rmvcity.h"
#include "ui_rmvcity.h"

////*****Global variables
QString removeItem; ///Saves the name of the item that will be removed
QString cityRemove; ///Saves the name of the city the user selected
////*****

//// Contructor
RmvCity::RmvCity(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RmvCity)
{
    ui->setupUi(this);
    this->setWindowTitle("Remove a Food Item");

    SetupComboBox(ui);
    LoadDatabase(ui);

    ///Ensures the program does not break
    ui->Go_Button->setDisabled(true);
    ui->Save_Button->setDisabled(true);
    ui->CityName_Line->setDisabled(true);
}

//// Destructor
RmvCity::~RmvCity()
{
    delete ui;
}

//// Loads and displays the food_costs database in the tableView.
////
//// \brief RmvCity::LoadDatabase
//// \param ui
////
void RmvCity::LoadDatabase(Ui::RmvCity *ui) {
    /// Load Food Costs database
    QSqlQuery query;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select * from food_costs");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){   /// Get next line
            food.push_back(query.value(1).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query);
    ui->tableView_2->setModel(foodM);
}

//// Sets the labels for the comboBox from cities that exist in the database.
////
//// \brief RmvCity::SetupComboBox
//// \param ui
////
void RmvCity::SetupComboBox(Ui::RmvCity *ui) {
    /// Default first value
    ui->comboBox->addItem("Please Select");

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->comboBox->addItem("-----------------------");
    }   /// If database can not be opened
    else{
        ui->comboBox->addItem("XXXXXXXXXXXXXXXXXXXXXXX");
    }

    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select starting_city from distanceTable group by"
                  " starting_city");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Set menu labels
    while(!places.empty()) {
        ui->comboBox->addItem(places.front());
        places.pop_front();
    }
}

//// Removes the food item from the database with the given name.
////
//// \brief RmvCity::Remove
//// \param
////
void RmvCity::Remove() {
    if(ui->CityName_Line->text() == NULL) {
        NoInput noInWin;
        noInWin.setModal(true);
        noInWin.exec();
    } else {
        const QString item = removeItem;

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("DELETE FROM food_costs WHERE food = :fItem");
        query.bindValue(":fItem", item);

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView_2->setModel(foodM);
    }
}

//// Closes the RmvCity window.
////
//// \brief RmvCity::on_Done_Button_clicked
//// \param
////
void RmvCity::on_Done_Button_clicked()
{
    this->close();
}

//// Displays the city selected by the comboBox in the table view.
////
//// \brief RmvCity::on_Go_Button_clicked
//// \param
////
void RmvCity::on_Go_Button_clicked()
{
    QString city = cityRemove;

    if(city == "Please Select") {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
            ui->comboBox->addItem("-----------------------");
        }   /// If database can not be opened
        else{
            ui->comboBox->addItem("XXXXXXXXXXXXXXXXXXXXXXX");
        }

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from food_costs");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView_2->setModel(foodM);
    } else {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
            ///ui->label->setText("Opened database successfully");
        }   /// If database can not be opened
        else{
            ///ui->label->setText("Can't open database");
        }

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from food_costs where city = \"" + city + "\"");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView_2->setModel(foodM);

        ///Ensures the user does not break program
        ui->CityName_Line->setEnabled(true);
    }
}

//// Executes function Remove() thus removing the item from the database.
////
//// \brief RmvCity::on_Save_Button_clicked
//// \param
////
void RmvCity::on_Save_Button_clicked()
{
   Remove();
   ui->Go_Button->click();
   ui->Save_Button->setDisabled(true);
}

//// Ensures the user can only input a string.
////
//// \brief RmvCity::on_CityName_Line_textEdited
//// \param
////
void RmvCity::on_CityName_Line_textEdited(const QString &arg1)
{
    removeItem = arg1;      ///saves the input
    ui->Save_Button->setEnabled(true);  ///Sets the save button to enable
}

//// Ensures the user cannot break the program.
////
//// \brief RmvCity::on_comboBox_activated
//// \param
////
void RmvCity::on_comboBox_activated(const QString &arg1)
{
    ///Ensure the user does not break program
    if(arg1 != "-----------------------" && arg1 != "Please Select"){
        cityRemove = arg1;        ///saves the starting city the user chose
        ui->Go_Button->setEnabled(true);   ///Sets the go button
    }
}
