/********************************************************************************
** Form generated from reading UI file 'editfood.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITFOOD_H
#define UI_EDITFOOD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_EditFood
{
public:
    QLineEdit *FoodItem_Line;
    QLineEdit *FoodCost_Line;
    QLabel *label_2;
    QLabel *label_3;
    QTableView *tableView;
    QComboBox *comboBox;
    QPushButton *Go_Button;
    QLabel *label;
    QPushButton *Done_Button;
    QPushButton *Save_Button;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;

    void setupUi(QDialog *EditFood)
    {
        if (EditFood->objectName().isEmpty())
            EditFood->setObjectName(QStringLiteral("EditFood"));
        EditFood->resize(545, 633);
        FoodItem_Line = new QLineEdit(EditFood);
        FoodItem_Line->setObjectName(QStringLiteral("FoodItem_Line"));
        FoodItem_Line->setGeometry(QRect(40, 180, 351, 30));
        FoodCost_Line = new QLineEdit(EditFood);
        FoodCost_Line->setObjectName(QStringLiteral("FoodCost_Line"));
        FoodCost_Line->setGeometry(QRect(40, 250, 91, 31));
        label_2 = new QLabel(EditFood);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 150, 91, 20));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);
        label_3 = new QLabel(EditFood);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(30, 220, 111, 20));
        label_3->setFont(font);
        tableView = new QTableView(EditFood);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(40, 310, 351, 300));
        comboBox = new QComboBox(EditFood);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(40, 110, 141, 31));
        Go_Button = new QPushButton(EditFood);
        Go_Button->setObjectName(QStringLiteral("Go_Button"));
        Go_Button->setGeometry(QRect(200, 110, 71, 31));
        label = new QLabel(EditFood);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 81, 311, 20));
        label->setFont(font);
        Done_Button = new QPushButton(EditFood);
        Done_Button->setObjectName(QStringLiteral("Done_Button"));
        Done_Button->setGeometry(QRect(431, 580, 85, 25));
        Save_Button = new QPushButton(EditFood);
        Save_Button->setObjectName(QStringLiteral("Save_Button"));
        Save_Button->setGeometry(QRect(430, 550, 85, 25));
        label_4 = new QLabel(EditFood);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(140, 0, 331, 71));
        QFont font1;
        font1.setPointSize(26);
        font1.setBold(true);
        font1.setUnderline(true);
        font1.setWeight(75);
        label_4->setFont(font1);
        label_5 = new QLabel(EditFood);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(160, 290, 131, 21));
        label_5->setFont(font);
        label_6 = new QLabel(EditFood);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(50, 613, 291, 20));

        retranslateUi(EditFood);

        QMetaObject::connectSlotsByName(EditFood);
    } // setupUi

    void retranslateUi(QDialog *EditFood)
    {
        EditFood->setWindowTitle(QApplication::translate("EditFood", "Dialog", 0));
        label_2->setText(QApplication::translate("EditFood", "Food Item:", 0));
        label_3->setText(QApplication::translate("EditFood", "New Food Cost: ", 0));
        Go_Button->setText(QApplication::translate("EditFood", "Go!", 0));
        label->setText(QApplication::translate("EditFood", "Select the City for a Menu item to be Edited:", 0));
        Done_Button->setText(QApplication::translate("EditFood", "Close", 0));
        Save_Button->setText(QApplication::translate("EditFood", "Edit", 0));
        label_4->setText(QApplication::translate("EditFood", "Edit a Menu Item", 0));
        label_5->setText(QApplication::translate("EditFood", "Food Cost Table", 0));
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class EditFood: public Ui_EditFood {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITFOOD_H
