#ifndef EDITFOOD_H
#define EDITFOOD_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "noinput.h"

namespace Ui {
class EditFood;
}

class EditFood : public QDialog
{
    Q_OBJECT

public:

    /// Loads the food cost database into the table view
    void LoadFoodCostDatabase();

    /// Edits the cost of food
    void Edit();

    /// Sets the menu labels for drop down menu
    void SetupComboBox(Ui::EditFood *ui);

    /// Default constructor
    explicit EditFood(QWidget *parent = 0);

    /// Default destructor
    ~EditFood();

private slots:

    void on_Save_Button_clicked();

    void on_Done_Button_clicked();

    void on_Go_Button_clicked();

    void on_FoodItem_Line_textEdited(const QString &arg1);

    void on_FoodCost_Line_textEdited(const QString &arg1);

    void on_comboBox_activated(const QString &arg1);

private:
    Ui::EditFood *ui;
};

#endif /// EDITFOOD_H
