#ifndef NOINPUT_H
#define NOINPUT_H

#include <QDialog>

namespace Ui {
class NoInput;
}

class NoInput : public QDialog
{
    Q_OBJECT

public:
    /// Default Constructor
    explicit NoInput(QWidget *parent = 0);

    /// Default Destructor
    ~NoInput();

private slots:
    void on_Ok_Button_clicked();

private:
    Ui::NoInput *ui;
};

#endif /// NOINPUT_H
