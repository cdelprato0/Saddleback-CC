#ifndef FOOD_H
#define FOOD_H

#include <QString>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include <QList>
#include <iostream>
#include <QVector>

class Food {
public:
    /// ctor/dtor
    /// Default Constructor
    ///
    /// \brief Food
    ///
    Food() {
        item = " ";
        price = 0;
        city = " ";
    }

    /// Overloaded Constructor:
    ///      Takes in the name of a food item as a QString and finds the corresponding
    ///          price abd city using the database
    ///
    /// \brief Food
    /// \param itemIn
    ///
    Food(QString itemIn) {
        item = itemIn;
        price = FindPrice();
        city = FindCity();
    }

    /// Overloaded Constructor:
    ///      Takes in the name of a food item as a QString and and the price of the
    ///          item then finds the corresponding city using the database
    ///
    /// \brief Food
    /// \param itemIn
    /// \param priceIn
    ///
    Food(QString itemIn, double priceIn) {
        item = itemIn;
        price = priceIn;
        city = FindCity();
    }

    /// Default dtor
    ~Food() {}



    /// Accessors

    /// Returns the name of the item as a QString
    ///
    /// \brief ReturnItem
    /// \return QString of the item name
    ///
    QString ReturnItem() {
        return item;
    }

    /// Returns the price of the item as a double
    ///
    /// \brief ReturnPrice
    /// \return double of the items price
    ///
    double ReturnPrice() {
        return price;
    }

    /// Returns the name of the city where the item is found as a QString
    ///
    /// \brief ReturnCity
    /// \return QString of the city name
    ///
    QString ReturnCity() {
        return city;
    }

private:
    /// Mutators
    /// Finds the price of an item using a database query
    ///      Returns as a double
    ///
    /// \brief FindPrice
    /// \return double of the cost of the item
    ///
    double FindPrice() {
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        database.open();

        QSqlQuery query;        /// SQL command to be executed (query.exec)

        /// SQL Command to be executed
        query.prepare("select cost from food_costs where food = \"" + item + "\"");
        query.exec();
        query.first();

        return (query.value(0).toDouble());
    }


    /// Finds the name of a city using a database query
    ///      Returns as a QString
    ///
    /// \brief FindCity
    /// \return QString of the city name
    ///
    QString FindCity() {
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        database.open();

        QSqlQuery query;        /// SQL command to be executed (query.exec)

        /// SQL Command to be executed
        query.prepare("select city from food_costs where food = \"" + item + "\"");
        query.exec();
        query.first();

        return (query.value(0).toString());
    }

    /// DATA MEMBERS
    QString city;               /// \brief Name of the city of the corresponding item
    QString item;               /// \brief Name of the item of food
    double price;               /// \brief Price of the food item
};



class FoodReciept {
public:
    /// ctor / dtor
    /// Default Constructor
    FoodReciept() {}

    /// Default dtor
    ~FoodReciept() {}

    /// Mutators
    /// Inserts a node of Food into the foodList<Food> list
    ///      Takes in the name of an itme then through the overloaded Food ctor
    ///          finds the corresponding price and city name
    ///      If the city of the food item does not already exist in the foodList
    ///          then the city will be added to the cities<QString> vector
    ///      The total will be recalucalted and updated after every insertion
    ///
    /// \brief insert
    /// \param item
    ///
    void insert(QString item) {
        Food tmp(item);                 /// Temporary node that will be inserted
        bool exist = false;             /// If the city exists in foodList
        Food tmp2;                      /// Temporary node holding the current
                                        ///      index Food Object

        for(int i = 0;i < foodList.size(); i++) {
            tmp2 = foodList.at(i);
            if(tmp.ReturnCity() == tmp2.ReturnCity()) {
                exist = true;
            }
        }

        /// If the the cty does not exist in foodList<Food> the add it to the
        ///      citites<QString> vector
        if(exist == false) {
            cities.push_front(tmp.ReturnCity());
        }

        foodList.append(tmp);               ///  Add tmp node to the end of foodList
        GetTotal();                         ///  Recalcuate and update total

    }

    /// Removes a node of Food from the foodList<Food> list
    ///      Searches foodList<Food> for a given Food Object from the given QString
    ///      If the given object is found the index will be saved into index
    ///      The city of the given object will be removed from cities<QString>
    ///          vector if only one occurance of the city exists in foodList<Food>
    ///      The found Food object will be from index to index 0 and will be removed
    ///          from the foodList using pop_front()
    ///      The total will be recalculated and updated after every deletion
    ///
    /// \brief remove
    /// \param item
    ///
    void remove(QString item) {
        Food tmp;                       /// Temporary node holding the current index Food Object
        bool found = false;             /// If the searched for item is found
        int cityCount = 0;              /// Number of times a particular city is found
        int index = 0;                  /// Index of the found object being removed

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnItem() == item) {
                found = true;
                index = i;
                break;
            }
        }

        Food tmp2;                      /// Temporary node holding the current index Food Object

        if(found) {
            for(int i = 0;i < foodList.size(); i++) {
                tmp2 = foodList.at(i);

                if(tmp.ReturnCity() == tmp2.ReturnCity()) {
                    cityCount++;
                }
            }

            if(cityCount == 1) {
                cities.removeOne(tmp.ReturnCity());
            }

            foodList.move(index,0);     /// Moves the fouond object to the front
            foodList.pop_front();       /// Removes the front object of foodList
        }

        GetTotal();                     /// Recalculate and update total
    }

    /// Calculates the total of the current objects in foodList<Food>
    ///      returns nothing
    ///
    /// \brief GetTotal
    ///
    void GetTotal() {
        total = 0.0;            /// Resets the data member total
        Food tmp;               /// Temporary Food node holding the current index object
        double cost = 0.0;      /// Cost of the current index Food object

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);
            cost  = tmp.ReturnPrice();

            total+= cost;
        }
    }

    /// Accessors
    /// Returns the total for the city of Amsterdam
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief AmsterdamTotal
    /// \return double of Amsterdams total
    ///
    double AmsterdamTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Amsterdam")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Berlin
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief BerlinTotal
    /// \return double of Berlins total
    ///
    double BerlinTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Berlin")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Brussels
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief BrusselsTotal
    /// \return double of Brussels total
    ///
    double BrusselsTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Brussels")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Budapest
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief BudapestTotal
    /// \return double of Budapests total
    ///
    double BudapestTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Budapest")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Hamburg
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief HamburgTotal
    /// \return double of Hamburgs total
    ///
    double HamburgTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Hamburg")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of London
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief LondonTotal
    /// \return double of Londons total
    ///
    double LondonTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "London")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Lisbon
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief LisbonTotal
    /// \return double of Lisbons total
    ///
    double LisbonTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Lisbon")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Madrid
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief MadridTotal
    /// \return double of Madrids total
    ///
    double MadridTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Madrid")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Paris
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief ParisTotal
    /// \return double of Paris' total
    ///
    double ParisTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Paris")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Prague
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief PragueTotal
    /// \return double of Pragues total
    ///
    double PragueTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Prague")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Rome
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief RomeTotal
    /// \return double of Romes total
    ///
    double RomeTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Rome")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Stockholm
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief StockholmTotal
    /// \return double of Stockholms total
    ///
    double StockholmTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Stockholm")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the total for the city of Vienna
    ///      Searches the foodList<Food> for items in the respective city and
    ///              totals those costs
    ///
    /// \brief ViennaTotal
    /// \return double of Viennas total
    ///
    double ViennaTotal() {
        double total = 0.0;
        Food tmp;

        for(int i = 0; i < foodList.size(); i++) {
            tmp = foodList.at(i);

            if(tmp.ReturnCity() == "Vienna")
                total += tmp.ReturnPrice();
        }

        return total;
    }

    /// Returns the Current total cost of all Food objects in foodList<Food>
    ///
    /// \brief ReturnTotal
    /// \return double of the current total
    ///
    double ReturnTotal() {
        return total;
    }

    /// RECIEPT PRINT OUT
    /// Returns a QString of all items purchased and their respective costs
    /// All citites will have their own totals
    /// A grand total will be provided as well
    ///
    /// \brief Print
    /// \return QString for the reciept
    ///
    QString Print() {
        QString data;
        Food tmp;

        /// Amsterdam
        if(cities.contains("Amsterdam")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Amsterdam: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Amsterdam") {                    
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(AmsterdamTotal()));
            data.append("\n\n");
        }

        /// Berlin
        if(cities.contains("Berlin")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Berlin: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Berlin") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 12){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(BerlinTotal()));
            data.append("\n\n");
        }

        /// Brussels
        if(cities.contains("Brussels")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Brussels: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Brussels") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(BrusselsTotal()));
            data.append("\n\n");
        }

        /// Budapest
        if(cities.contains("Budapest")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Budapest: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Budapest") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(BudapestTotal()));
            data.append("\n\n");
        }

        /// Hamburg
        if(cities.contains("Hamburg")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Hamburg: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Hamburg") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(HamburgTotal()));
            data.append("\n\n");
        }

        /// London
        if(cities.contains("London")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("London: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "London") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(LondonTotal()));
            data.append("\n\n");
        }

        ///Lisbon
        if(cities.contains("Lisbon")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Lisbon: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Lisbon") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(LisbonTotal()));
            data.append("\n\n");
        }

        /// Madrid
        if(cities.contains("Madrid")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Madrid: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Madrid") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(MadridTotal()));
            data.append("\n\n");
        }

        /// Paris
        if(cities.contains("Paris")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Paris: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Paris") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(ParisTotal()));
            data.append("\n\n");
        }

        /// Prague
        if(cities.contains("Prague")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Prague: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Prague") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(PragueTotal()));
            data.append("\n\n");
        }

        /// Rome
        if(cities.contains("Rome")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Rome: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Rome") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(RomeTotal()));
            data.append("\n\n");
        }

        /// Stockholm
        if(cities.contains("Stockholm")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Stockholm: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Stockholm") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(StockholmTotal()));
            data.append("\n\n");
        }

        /// Vienna
        if(cities.contains("Vienna")) {
            for(int i = 0; i < foodList.size(); i++) {
                i == 0 ? data.append("Vienna: \n") : data.append("");

                tmp = foodList.at(i);

                if(tmp.ReturnCity() == "Vienna") {
                    data.append(tmp.ReturnItem());
                    if(tmp.ReturnItem().length() > 11){
                        data.append("\t\t\t");
                    }else{
                        data.append("\t\t\t\t");
                    }
                    data.append("$" + QString("%1").arg(tmp.ReturnPrice()));
                    data.append("\n");
                }
            }

            data.append("\n\t\tTotal: $");
            data.append(QString("%1").arg(ViennaTotal()));
            data.append("\n\n");
        }

        /// Grand total
        data.append("\n\n\tGrand Total: $");
        data.append(QString("%1").arg(ReturnTotal()));
        data.append("\n\n\n                Thank you for Traveling Europe with Team AOA!");

        return data;
    }

private:
    /// DATA MEMBERS
    QVector<QString> cities;        /// \brief Vector holding the cities where food was purchased
    QList<Food> foodList;           /// \brief List of type Food holding all items purchased
    double total = 0.0;             /// \brief current total of items in foodList<Food>
};

#endif /// FOOD_H
