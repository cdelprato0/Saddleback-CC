#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include <QDialog>
#include "ui_adminwindow.h"
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "mainwindow.h"
#include "editfood.h"
#include "rmvcity.h"
#include "addcity.h"
#include "addfood.h"

namespace Ui {
class AdminWindow;
}

class AdminWindow : public QDialog
{
    Q_OBJECT

public:
    /// Initialize and present both databases
    void LoadDatabase(Ui::AdminWindow *ui);

    /// Loads the window
    void SetupWindow(Ui::AdminWindow *ui);

    /// Populates the drop down box with cities to chose from
    void SetupComboBox(Ui::AdminWindow *ui);

    explicit AdminWindow(QWidget *parent = 0);
    ~AdminWindow();

private slots:
    void on_removeCities_Button_clicked();

    void on_AddCities_Button_clicked();

    void on_editCities_Button_clicked();

    void on_logOut_Button_clicked();

    void on_pushButton_clicked();

    void on_AddFoodItem_Button_clicked();

private:
    Ui::AdminWindow *ui;
};

#endif /// ADMINWINDOW_H
