#ifndef VISITALLCITIES_H
#define VISITALLCITIES_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "food.h"
#include "reciept.h"

namespace Ui {
class VisitAllCities;
}

class VisitAllCities : public QDialog
{
    Q_OBJECT

public:
    /// Default Constructor
    explicit VisitAllCities(QWidget *parent = 0);

    /// Default Destructor
    ~VisitAllCities();

    void ReadDatabase(Ui::VisitAllCities *ui);

    void SetTable(Ui::VisitAllCities *ui, QString place);

    FoodReciept reciept;    ///Used for creating reciept window

private slots:
    ///Next button
    void on_pushButton_clicked();

    ///Close button
    void on_pushButton_2_clicked();

    ///left side table view
    void on_tableView_doubleClicked(const QModelIndex &index);

    ///right side list widget
    void on_listWidget_doubleClicked(const QModelIndex &index);

private:
    Ui::VisitAllCities *ui;
};

#endif /// VISITALLCITIES_H
