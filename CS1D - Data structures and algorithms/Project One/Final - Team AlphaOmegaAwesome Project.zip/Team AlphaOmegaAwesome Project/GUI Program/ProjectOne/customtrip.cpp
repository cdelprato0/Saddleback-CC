#include "customtrip.h"
#include "ui_customtrip.h"

////*****Global Variables
QList<QString> plannedTrip; ///Keeps track of all the city names that are wanting to be visited from selection
QList<QString> route;       ///Keeps track of the route of the trip, meaning that it holds the names of the cities that are going to be visited next

QString startingCity;       ///The city that has been selected from the combo box
int shortestDistance = 0;   ///Used to determine the shorest distance between two cities
int totalDist = 0;          ///Accumlates the total distance of the trip
////*****

////Default Constructor
CustomTrip::CustomTrip(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CustomTrip)
{
    ui->setupUi(this);

    ///Reads in the SQL Database
    ReadDatabase(ui);

    ///Sets up the combo box
    SetupComboBox(ui);

    ///Disables all buttons so the user can not break program
    ui->Go->setDisabled(true);
    ui->NextCity->setDisabled(true);
    ui->PlanTrip->setDisabled(true);
}

////Deconstructor
CustomTrip::~CustomTrip()
{
    delete ui;
}

//// The Readdatabe method will read in the SQL databse.
//// will output and error if the database was not opened correctly.
////
//// \brief CustomTrip::ReadDatabase
//// \param ui
////
void CustomTrip::ReadDatabase(Ui::CustomTrip *ui){

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->label->setText("Opened database successfully");
    }   /// If database can not be opened
    else{
        ui->label->setText("Can't open database");
    }
}///END ReadDatabase

////The SetTable method will recieve in a name of a city.
////Then the method will read in all of the possible city you can travel to and their distances
////
//// \brief CustomTrip::SetTable
//// \param ui
//// \param city
////
void CustomTrip::SetTable(Ui::CustomTrip *ui, QString city){

    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select * from distanceTable where starting_city = \"" + city + "\"");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }
    }
    else{   ///If an error occurs
        qDebug() << query.lastError();
    }

    /// Distance Table view
    QSqlQueryModel *distM= new QSqlQueryModel();
    distM->setQuery(query);
    ui->tableView->setModel(distM);

    ///Hides the first Column
    ui->tableView->setColumnHidden(0, true);
}///END SetTable

////The SetUpComboBox method will load all of the names of the cities that the user can choose from.
////Once the user chooses the starting city it will call the databse and return all the possible cities the user can go after the starting city
////
//// \brief CustomTrip::SetupComboBox
//// \param ui
////
void CustomTrip::SetupComboBox(Ui::CustomTrip *ui) {
    /// Default first value
    ui->comboBox->addItem("Please Select");

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->comboBox->addItem("-----------------------");
    }   /// If database can not be opened
    else{
        ui->comboBox->addItem("XXXXXXXXXXXXXXXXXXXXXXX");
    }


    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select starting_city from distanceTable group by"
                  " starting_city");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }
    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Set menu labels
    while(!places.empty()) {
        ui->comboBox->addItem(places.front());
        places.pop_front();
    }
}///END SetUpComboBox

////This method will return the cities that have been selected for the trip into the list view on the right of the window
////
//// \brief CustomTrip::getAddedCityList
////
void CustomTrip::getAddedCityList(){
    for(int index = 0; index < plannedTrip.size(); index++){
        ///Adds all the names of the cities to the right list view
        ui->listWidget->addItem(plannedTrip.at(index));
    }
}///End getAddedCities

///When TableView is double clicked
//// This will add the name of the city that was clicked on to a list.
//// It will output what city was added to the right list view.
////
//// \brief CustomTrip::on_tableView_doubleClicked
//// \param index
////
void CustomTrip::on_tableView_doubleClicked(const QModelIndex &index)
{
    QString addedCity; ///Saves the data that was double clicked

    ///Saves the data that was double clicked on the table view by the user
    addedCity = index.data(Qt::DisplayRole).toString();

    ui->listWidget->addItem(addedCity); ///outputs to the list view
    ui->PlanTrip->setEnabled(true); ///Enables the plan trip button
    ui->tableView->setRowHidden(index.row(), true); ///Hides the row after selection

    ///Adds the city name to the trip
    plannedTrip.push_front(addedCity);
}

/// When List View is Double Clicked
//// This will remove a city that is part of the planned trip.
//// It will remove the name off of the list view and reload the remaining citys on the list
////
//// \brief CustomTrip::on_listWidget_doubleClicked
//// \param index
////
void CustomTrip::on_listWidget_doubleClicked(const QModelIndex &index)
{
    QString removeCity; ///Saves the name of the city that was double clicked
    removeCity = index.data(Qt::DisplayRole).toString();

    ///removed it from the list
    plannedTrip.removeAll(removeCity);

    ui->listWidget->clear();    ///clears the lsit view

    if(plannedTrip.size() == 0){   ///If there is no cities to visit
        ui->PlanTrip->setDisabled(true); ///Set the plan trip button to disabled
    }

    ///Calls this function load the list view with the remaining cities
    getAddedCityList();
}

/// Plan Trip button
//// This button will recieve the starting city selected from the combo box.
//// The starting city will find a city that is the closest and also a part of the planned trip.
//// Once it finds out the next closest city it will save that value.
//// It will start the trip after that and output the menu items of the first city into the table view.
////
//// \brief CustomTrip::on_PlanTrip_clicked
////
void CustomTrip::on_PlanTrip_clicked()
{
    QSqlQuery query;            ///SQL database comms
    QList<int> cityDistance;    ///Savers the city's distances into a list
    QList<QString> cityNames;   ///Saves the city's names into a list
    QMap<QString, int> map;     ///Saves both the names (key) and distances (values) into a map data structure


    ///Reads from the database the starting city that has been passed into this function
    query.prepare("select * from distanceTable where starting_city = \"" + startingCity + "\"");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line

            ///Adds all the distances to this list so that the list can be gone through and used to determine the shortest distance
            cityDistance.push_back(query.value(2).toInt());

            ///Adds the names of the cities to be used as the key of the map
            cityNames.push_back(query.value(1).toString());

        }///End WHILE
    }///End IF
    else{   /// If Error occurs
        qDebug() << query.lastError();
    }///End ELSE


    ///Clears the list view and disables and enables labeled buttons
    ui->listWidget->clear();
    ui->PlanTrip->setDisabled(true);
    ui->NextCity->setEnabled(true);


    /// Load Food Costs database
    QSqlQuery query2;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query2.prepare("select * from food_costs where city = \"" + startingCity + "\"");

    /// Execute and populate QList<string> with database info
    if(query2.exec()){
        while(query2.next()){   /// Get next line
            food.push_back(query2.value(1).toString());
        }
    }
    else{
        qDebug() << query2.lastError();
    }

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query2);
    ui->Menu->setModel(foodM);


    ///Creates a map from the lists that was pulled from the database.
    ///Purpose of the map is to compare and keep track of the cities already visited
    for(int index = 0; index < cityNames.size();index ++){
        map.insert(cityNames.at(index), cityDistance.at(index));
    }

    shortestDistance = 10000; ///Sets a high number so that the distances can be compared to something

    ///Runs through the list of distances so that it can determine the shortest distance
    for(int index = 0; index < cityDistance.size(); index++){
        ///If the names in the planned trip contain the names of the info read in from the database
        if(plannedTrip.contains(cityNames.at(index))){
            ///It will check to see which city is the closest
            if(cityDistance.at(index) < shortestDistance){
                shortestDistance = cityDistance.at(index); ///Saves the shortest distance to the next city
            }
        }
    }

    totalDist = shortestDistance;                       ///Accumlates the total distance
    route.push_front(map.key(shortestDistance));        ///Adds the next city that is going to be visited to a list
    plannedTrip.removeAll(map.key(shortestDistance));   ///Removes the city name from the planned trip after visit

    ui->Menu->setColumnHidden(0, true); ///Hides first column
    ui->label_5->setText("Welcome to " + startingCity + "!");   ///Outputs to label where we are at
}

/// Go Button
//// Once clicked the button will load the cities that can be visited from the starting city.
////
//// \brief CustomTrip::on_Go_clicked
////
void CustomTrip::on_Go_clicked()
{
    ///Sets the table view
    SetTable(ui, startingCity);

    ///Disables the go button
    ui->Go->setDisabled(true);
}

/// Next City Button
//// When this button is pressed, the method will call the database to receive the next city's possible places you can travel.
//// The names and distances will be saved into lists and then added into a map to be compared.
//// The method will determine the shortest distance to the next city and add that city to the route.
//// This method will keep track of the total distance traveled.
////
//// \brief CustomTrip::on_NextCity_clicked
////
void CustomTrip::on_NextCity_clicked()
{
    QSqlQuery query;            ///SQL database comms
    QList<int> cityDistance;    ///Savers the city's distances into a list
    QList<QString> cityNames;   ///Saves the city's names into a list
    QMap<QString, int> map;     ///Saves both the names (key) and distances (values) into a map data structure


    ///Reads from the database the starting city that has been passed into this function
    query.prepare("select * from distanceTable where starting_city = \"" + route.at(0) + "\"");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line

            ///Adds all the distances to this list so that the list can be gone through and used to determine the shortest distance
            cityDistance.push_back(query.value(2).toInt());

            ///Adds the names of the cities to be used as the key of the map
            cityNames.push_back(query.value(1).toString());

        }///End WHILE
    }///End IF
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }///End ELSE


    /// Load Food Costs database
    QSqlQuery query2;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query2.prepare("select * from food_costs where city = \"" + route.at(0) + "\"");

    /// Execute and populate QList<string> with database info
    if(query2.exec()){
        while(query2.next()){   /// Get next line
            food.push_back(query2.value(1).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query2.lastError();
    }

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query2);
    ui->Menu->setModel(foodM);


    ///Creates a map from the lists that was pulled from the database.
    ///Purpose of the map is to compare and keep track of the cities already visited.
    for(int index = 0; index < cityNames.size();index ++){
        map.insert(cityNames.at(index), cityDistance.at(index));
    }

    shortestDistance = 10000; ///Sets a high number so that the distances can be compared to something

    ///Runs through the list of distances so that it can determine the shortest distance
    for(int index = 0; index < cityDistance.size(); index++){
        ///If the names in the planned trip contain the names of the info read in from the database
        if(plannedTrip.contains(cityNames.at(index))){
            ///It will check to see which city is the closest
            if(cityDistance.at(index) < shortestDistance){
                shortestDistance = cityDistance.at(index); ///Saves the shortest distance to the next city
            }
        }
    }

    ui->label_5->setText("Welcome to " + route.at(0) + "!");    ///Outputs the city we are at

    ///If the trip is over
    if(route.at(0) == "" ){
        ///Output the total distance
        ui->label_5->setText("Thank you for Visiting Europe!!");
        ui->label_3->setText("The Total Distance of this trip is: " + QString::number(totalDist - 10000) + "km!");
        ui->NextCity->setDisabled(true);    ///Disables the Next city button on last city
        ui->Menu->setColumnHidden(1,true);  ///Sets the left table to look empty
        ui->Menu->setColumnHidden(2,true);  ///Sets the left table to look empty

        ///Creats the Reciept page to pop up
        FoodReciept* ptr = &reciept;
        Reciept rcptWin(*ptr);
        rcptWin.setModal(true);
        rcptWin.exec();
    }

    totalDist += shortestDistance;              ///Accumlates the total distance
    route.removeAt(0);                          ///Removes the front of the route since it has already been visited
    route.push_front(map.key(shortestDistance));///Adds the new closest city to the route
    plannedTrip.removeAll(map.key(shortestDistance)); ///Removes the city from the planned trip

    if(route.at(0) == "" ){
        ui->NextCity->setText("Complete Trip"); ///Changes the name of the button at the end of the button
    }
}

///Once you click on an item in the combo box
void CustomTrip::on_comboBox_activated(const QString &arg1)
{
    ///Ensure the user does not break program
    if(arg1 != "-----------------------" && arg1 != "Please Select"){
        startingCity = arg1;        ///saves the starting city the user chose
        ui->Go->setEnabled(true);   ///Sets the go button
    }
}

///Close button
void CustomTrip::on_Close_clicked()
{
    this->close();
}

void CustomTrip::on_Menu_doubleClicked(const QModelIndex &index)
{
    /// Returns a QString of the item selected
    QString data = (index.data(Qt::DisplayRole).toString());

    /// Adds the item to the receipt list
    reciept.insert(data);

    /// Adds the item to the reciept view QListWidget
    ui->Reciept->addItem(data);

    /// Sets the total_label with the running total (updataed after every addition)
    ui->label_6->setText("Current Total Cost: $" + QString("%1").arg(reciept.ReturnTotal()));
}

void CustomTrip::on_Reciept_doubleClicked(const QModelIndex &index)
{
    /// Returns a QString of the item selected
    QString data = (index.data(Qt::DisplayRole).toString());

    /// Row of the selected item
    int row = index.row();

    /// Removes the selected row from the QListWidget
    QListWidgetItem* item = ui->Reciept->takeItem(row);

    /// Removes the item from the reciept list
    reciept.remove(data);

    /// Deletes the item removed from the QListWidget
    delete item;

    /// Sets the total_label with the running total (updataed after every addition)
    ui->label_6->setText("Current Total Cost: $" + QString("%1").arg(reciept.ReturnTotal()));
}
