#include "shortesttrip.h"
#include "ui_shortesttrip.h"

////*****Global Variables
int chosenCount = 0;        ///Keeps track of the chosen amount from the spin box
int minDistance = 0;        ///Used to determine the shortest distance between two cities
int totDistance = 0;        ///Accumlates the total distance
int count = 0;              ///Keeps a count of how many cities have already been visited

QList<QString> currentCity; ///Keeps track of the cities that have been visited
////*****

////Default Constructor
ShortestTrip::ShortestTrip(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ShortestTrip)
{
    ui->setupUi(this);

    ///Reads in the database and sets up the table view
    ReadDatabase(ui);
    SetTable(ui, "Paris");

    ui->NextCity->setDisabled(true);    ///Diables the Next City button
    ui->tableView->setColumnHidden(0, true); ///Hides the first Column
}

////De-Constructor
ShortestTrip::~ShortestTrip()
{
    delete ui;
}

//// The Readdatabe method will read in the SQL databse.
//// will output and error if the database was not opened correctly.
////
//// \brief ShortestTrip::ReadDatabase
//// \param ui
////
void ShortestTrip::ReadDatabase(Ui::ShortestTrip *ui){

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->label->setText("Opened database successfully");
    }   /// If database can not be opened
    else{
        ui->label->setText("Can't open database");
    }
}

//// The SetTable method will recieve in a name of a city.
//// Then the method will read in all of the possible city you can travel to and their distances
////
//// \brief ShortestTrip::SetTable
//// \param ui
//// \param city
////
void ShortestTrip::SetTable(Ui::ShortestTrip *ui, QString city){

    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select * from distanceTable where starting_city = \"" + city + "\"");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{
        qDebug() << query.lastError();
    }

    /// Distance Table view
    QSqlQueryModel *distM= new QSqlQueryModel();
    distM->setQuery(query);
    ui->tableView->setModel(distM);

    ///Sets the min and max of the spin box
    ui->spinBox->setMinimum(1);
    ui->spinBox->setMaximum(places.size());
}

///Plan Trip button
//// This button will have the starting city be Paris.
//// It will load the table view with the menu items of Paris.
//// Also it will add Paris to the first spot on the currentCity route.
////
//// \brief ShortestTrip::on_PlanTrip_clicked
////
void ShortestTrip::on_PlanTrip_clicked()
{
    /// Load Food Costs database
    QSqlQuery query2;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query2.prepare("select * from food_costs where city = \"Paris\"");

    /// Execute and populate QList<string> with database info
    if(query2.exec()){
        while(query2.next()){   /// Get next line
            food.push_back(query2.value(1).toString());
        }
    }
    else{
        qDebug() << query2.lastError();
    }

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query2);
    ui->tableView->setModel(foodM);

    ///Adds Paris to the currentCity list. Used to compare in the next button
    currentCity.push_front("Paris");

    ///Disables and enables buttons so user does not break program
    ui->spinBox->setDisabled(true);
    ui->PlanTrip->setDisabled(true);
    ui->NextCity->setEnabled(true);

    ui->label_5->setText("Welcome to Paris!");
}

///Next City Button
//// When this button is pressed, the method will call the database to receive the next city's possible places you can travel.
//// The names and distances will be saved into lists and then added into a map to be compared.
//// The method will determine the shortest distance to the next city and add that city to the route.
//// The method is based on the users selection of how many cities they wanted to visit.
//// This method will keep track of the total distance traveled.
////
//// \brief ShortestTrip::on_NextCity_clicked
////
void ShortestTrip::on_NextCity_clicked()
{
    QSqlQuery query;            ///SQL database comms
    QList<int> cityDistance;    ///Savers the city's distances into a list
    QList<QString> cityNames;   ///Saves the city's names into a list
    QMap<QString, int> map;     ///Saves both the names (key) and distances (values) into a map data structure

    ///If the trip is on the last city, it will set the next button to this
    if(count + 1 == chosenCount){
        ui->NextCity->setText("Complete Trip");
    }

    ///Used to stop when the chosen count is met with the count of cities already visited
    if(count != chosenCount){

        ///Reads from the database the starting city that has been passed into this function
        query.prepare("select * from distanceTable where starting_city = \"" + currentCity.at(0) + "\"");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){    /// Get next line

                ///Adds all the distances to this list so that the list can be gone through and used to determine the shortest distance
                cityDistance.push_back(query.value(2).toInt());

                ///Adds the names of the cities to be used as the key of the map
                cityNames.push_back(query.value(1).toString());

            }///End WHILE
        }///End IF
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }///End ELSE


        ///Creates a map from the lists that was pulled from the database.
        ///Purpose of the map is to compare and keep track of the cities already visited.
        for(int index = 0; index < cityNames.size();index ++){
            map.insert(cityNames.at(index), cityDistance.at(index));
        }

        minDistance = 10000;///Sets a high number so that the distances can be compared to something

        ///Runs through the list of distances and determines the one that has the shorest distance
        for(int index = 0; index < cityDistance.size(); index++){

            ///Uses an if statement check to see what the smallest distance is from the starting place to the ending place
            if(cityDistance.value(index) < minDistance){
                minDistance = cityDistance.value(index);
            }
        }

        ///Checks to see if the city has already been visited or not, and if not it will determine the shortest distance
        while(currentCity.contains(map.key(minDistance))){
            ///Removes from the list to ensure the same city is not visited twice
            cityDistance.removeAll(minDistance);

            minDistance = 10000; ///Sets a high number so that the distances can be compared to something

            ///Runs through the list of distances and determines the one that has the shortest distance
            for(int index = 0; index < cityDistance.size(); index++){

                ///Uses an if statement check to see what the smallest distance is from the starting place to the ending place
                if(cityDistance.value(index) < minDistance){
                    minDistance = cityDistance.value(index);
                }
            }
        }

        totDistance += minDistance;                     ///Accumlates the total distance of the trip
        currentCity.push_front(map.key(minDistance));   ///Adds the name of the shortest distance between the cities

        /// Load Food Costs database
        QSqlQuery query2;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query2.prepare("select * from food_costs where city = \"" + currentCity.at(0) + "\"");

        /// Execute and populate QList<string> with database info
        if(query2.exec()){
            while(query2.next()){   /// Get next line
                food.push_back(query2.value(1).toString());
            }
        }
        else{
            qDebug() << query2.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query2);
        ui->tableView->setModel(foodM);

        count++;    ///Increments count so that it will exit if statement

        ui->label_5->setText("Welcome to " + currentCity.at(0) + "!");
    }
    else{
        ///Once the trip is complete it will output distance and disable button
        ui->label_5->setText("Thank you for Visiting Europe!!");
        ui->label_4->setText("The Total Distance of the trip was: " + QString::number(totDistance) + "km!");
        ui->NextCity->setDisabled(true);

        ///Creats the Reciept window
        FoodReciept* ptr = &reciept;
        Reciept rcptWin(*ptr);
        rcptWin.setModal(true);
        rcptWin.exec();
    }
}

///Spin box
////Takes the users selection of number of cities and saves it so the program knows when to stop.
void ShortestTrip::on_spinBox_valueChanged(int arg1)
{
    chosenCount = arg1;
}

///Close button
void ShortestTrip::on_Close_clicked()
{
    this->close();
}

///When the menu item is dobled clicked
void ShortestTrip::on_tableView_doubleClicked(const QModelIndex &index)
{
    /// Returns a QString of the item selected
    QString data = (index.data(Qt::DisplayRole).toString());

    /// Adds the item to the receipt list
    reciept.insert(data);

    /// Adds the item to the reciept view QListWidget
    ui->listWidget->addItem(data);

    /// Sets the total_label with the running total (updataed after every addition)
    ui->label_7->setText("Current Total Cost: $" + QString("%1").arg(reciept.ReturnTotal()));
}

///When the added menu item is double clicked
void ShortestTrip::on_listWidget_doubleClicked(const QModelIndex &index)
{
    /// Returns a QString of the item selected
    QString data = (index.data(Qt::DisplayRole).toString());

    /// Row of the selected item
    int row = index.row();

    /// Removes the selected row from the QListWidget
    QListWidgetItem* item = ui->listWidget->takeItem(row);

    /// Removes the item from the reciept list
    reciept.remove(data);

    /// Deletes the item removed from the QListWidget
    delete item;

    /// Sets the total_label with the running total (updataed after every addition)
    ui->label_7->setText("Current Total Cost: $" + QString("%1").arg(reciept.ReturnTotal()));
}
