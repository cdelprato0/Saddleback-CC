/********************************************************************************
** Form generated from reading UI file 'noinput.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOINPUT_H
#define UI_NOINPUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_NoInput
{
public:
    QPushButton *Ok_Button;
    QLabel *label;

    void setupUi(QDialog *NoInput)
    {
        if (NoInput->objectName().isEmpty())
            NoInput->setObjectName(QStringLiteral("NoInput"));
        NoInput->resize(340, 170);
        Ok_Button = new QPushButton(NoInput);
        Ok_Button->setObjectName(QStringLiteral("Ok_Button"));
        Ok_Button->setGeometry(QRect(115, 110, 110, 30));
        label = new QLabel(NoInput);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(42, 30, 251, 61));
        QFont font;
        font.setPointSize(14);
        label->setFont(font);

        retranslateUi(NoInput);

        QMetaObject::connectSlotsByName(NoInput);
    } // setupUi

    void retranslateUi(QDialog *NoInput)
    {
        NoInput->setWindowTitle(QApplication::translate("NoInput", "Dialog", 0));
        Ok_Button->setText(QApplication::translate("NoInput", "Ok", 0));
        label->setText(QApplication::translate("NoInput", "Please fill out every data field!", 0));
    } // retranslateUi

};

namespace Ui {
    class NoInput: public Ui_NoInput {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOINPUT_H
