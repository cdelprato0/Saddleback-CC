#ifndef RECIEPT_H
#define RECIEPT_H

#include <QDialog>
#include "food.h"

namespace Ui {
class Reciept;
}

class Reciept : public QDialog
{
    Q_OBJECT

public:
    /// Default constructor
    explicit Reciept(QWidget *parent = 0);

    /// Default destructor
    ~Reciept();

    /// Overloaded constructor
    ///  Takes a dereferenced pointer ( *ptr ) as a perameter
    explicit Reciept(FoodReciept &reciept);

    /// Prints the reciept and outputs it to a text broswer
    void WriteReciept(FoodReciept reciept);

private:
    Ui::Reciept *ui;
};

#endif /// RECIEPT_H
