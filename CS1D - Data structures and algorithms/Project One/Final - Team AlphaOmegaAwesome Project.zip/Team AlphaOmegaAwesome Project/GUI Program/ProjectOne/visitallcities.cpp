#include "visitallcities.h"
#include "ui_visitallcities.h"

////****Global Variables
QString place = "London";   ///The name of the starting place
int index = 0;              ///Keeps count of the city we are on
int smallestDistance = 0;   ///Used to compare the shorest distance
int totalDistance = 0;      ///Used to calculate the total distance of the trip

///Used to save the city name of the closest city to the startingPlace
QList<QString> closestCity = QList<QString>() << "London";
QMap< QString, int > map;   ///Holds the name of city (key) and the distance (value) the city is from the starting place
////*****

////Default Contructor
VisitAllCities::VisitAllCities(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::VisitAllCities)
{
    ui->setupUi(this);

    ///Reads in the data base
    ReadDatabase(ui);

    ///Sets the table view for the first city, London
    SetTable(ui, "London");

    ///Displays this labe at the top of the window
    ui->label_2->setText("Welcome to London!");
    ///Hides the first Column
    ui->tableView->setColumnHidden(0, true);
}

////Deconstructor
VisitAllCities::~VisitAllCities()
{
    delete ui;
}

//// Reads in the SQL Database for the database file found in the project
//// and also opens the database so that it can be accessed
////
//// \brief VisitAllCities::ReadDatabase
//// \param ui
////
void VisitAllCities::ReadDatabase(Ui::VisitAllCities *ui){

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->label->setText("Opened database successfully");
    }   /// If database can not be opened
    else{
        ui->label->setText("Can't open database");
    }
}///END ReadDatabase

//// This method creates that table of menu items for the current city.
//// The name of the current city is passed in and the database is accessed from there
//// and the table view is created.
////
//// \brief VisitAllCities::SetTable
//// \param ui
//// \param place
////
void VisitAllCities::SetTable(Ui::VisitAllCities *ui, QString place){

    /// Load Food Costs database
    QSqlQuery query2;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query2.prepare("select * from food_costs where city = \"" + place + "\"");

    /// Execute and populate QList<string> with database info
    if(query2.exec()){
        while(query2.next()){   /// Get next line
            food.push_back(query2.value(1).toString());
        }

    }
    else{   ///Outputs if there is an error to the console
        qDebug() << query2.lastError();
    }

    /// Creates Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query2);
    ui->tableView->setModel(foodM);
}///END SetTable

///Next city button
//// When this button is pressed, the method will call the database to receive the next city's possible places you can travel.
//// The names and distances will be saved into lists and then added into a map to be compared.
//// The method will determine the shorest distance to the next city and add that city to the route.
//// This method will keep track of the total distance traveled.
////
//// \brief VisitAllCities::on_pushButton_clicked
////
void VisitAllCities::on_pushButton_clicked()
{
    QSqlQuery query;            ///Used for SQL database
    QList<int> allCitiesDist;   ///Reads in all of the city distances from the startingPlace and is used to determine the shorest distance
    QList<QString> cities;      ///Reads in the name of the cities from the distance table so that it can be saved to the map

    ///Reads from the database the starting city that has been passed into this function
    query.prepare("select * from distanceTable where starting_city = \"" + place + "\"");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line

            ///Adds all the distances to this list so that the list can be gone through and used to determine the shortest distance
            allCitiesDist.push_back(query.value(2).toInt());

            ///Adds all the names of the possible cities to this list
            cities.push_back(query.value(1).toString());

        }///End WHILE
    }///End IF
    else{   ///If an error occurs
        qDebug() << query.lastError();
    }///End ELSE

    ///Creates a map from the lists that was pulled from the database.
    ///Purpose of the map is to compare and keep track of the cities already visited
    for(int index = 0; index < allCitiesDist.size();index ++){
        map.insert(cities.at(index), allCitiesDist.at(index));
    }

    ///Sets a high number so that the distances can be compared to something
    smallestDistance = 10000;

    ///Runs through the list of distances and determines the one that has the shortest distance
    for(int index = 0; index < allCitiesDist.size(); index++){

        ///Uses an if statement check to see what the smallest distance is from the starting place to the ending place
        if(allCitiesDist.value(index) < smallestDistance){
            smallestDistance = allCitiesDist.value(index);
        }
    }

    ///Checks to see if the city has already been visited or not, and if not it will determine the shortest distance
    while(closestCity.contains(map.key(smallestDistance))){
        ///Removes from the list to ensure the same city is not visited twice
        allCitiesDist.removeAll(smallestDistance);

        smallestDistance = 10000; ///Sets a high number so that the distances can be compared to something

        ///Runs through the list of distances and determines the one that has the shortest distance
        for(int index = 0; index < allCitiesDist.size(); index++){

            ///Uses an if statement check to see what the smallest distance is from the starting place to the ending place
            if(allCitiesDist.value(index) < smallestDistance){
                smallestDistance = allCitiesDist.value(index);
            }
        }
    }
    ///Accumlates the total distance of the trip
    totalDistance += smallestDistance;

    ///Adds the city with the shorest distance to this list so that it can be used for the begginning of this method.
    ///Used when the database is called again
    closestCity.push_front(map.key(smallestDistance));
    place = closestCity.at(0);

    ///If the city count is not equal to 10 then it will output
    if(index != cities.size()){
        ///Sets the table with the apporaite food information
        SetTable(ui, place);
        ///Displays the name of the current city at the top
        ui->label_2->setText("Welcome to " + place +"!");

    }else{
        ui->pushButton->setDisabled(true);  ///Disables the NEXT button at the end of the trip
        ui->label_2->setText("Thank you for traveling Europe!"); ///Changes the top labe to output this
        ui->label_3->setText("The Total Distance is: " + QString::number(totalDistance - 10000) + "km!"); ///Displays the total distance

        ///Creates the reciept window
        FoodReciept* ptr = &reciept;
        Reciept rcptWin(*ptr);
        rcptWin.setModal(true);
        rcptWin.exec();
    }

    ///If the city is equal to the last trip
    if(index == 9){
        ui->pushButton->setText("Complete Trip");   ///Changes the text in the NEXT button to this
    }
    index++; ///Keeps track of the city number we are on
}

//// Closes the VisitAllCities Window.
////
//// \brief VisitAllCities::on_pushButton_2_clicked
//// \param
////
void VisitAllCities::on_pushButton_2_clicked()
{
    this->close();
}

//// Adds the clicked item into the reciept tableView.  The String will be inserted
////     into the reciept list.
////
//// \brief VisitAllCities::on_tableView_doubleClicked
//// \param
////
void VisitAllCities::on_tableView_doubleClicked(const QModelIndex &index)
{
    /// Returns a QString of the item selected
    QString data = (index.data(Qt::DisplayRole).toString());

    /// Adds the item to the receipt list
    reciept.insert(data);

    /// Adds the item to the reciept view QListWidget
    ui->listWidget->addItem(data);

    /// Sets the total_label with the running total (updataed after every addition)
    ui->label_6->setText("Current Total Cost: $" + QString("%1").arg(reciept.ReturnTotal()));
}

//// Removes the selected itemform the reciept tableView.  Will also remove the
////     respective item from the reciept list.
////
//// \brief VisitAllCities::on_listWidget_doubleClicked
//// \param
////
void VisitAllCities::on_listWidget_doubleClicked(const QModelIndex &index)
{
    /// Returns a QString of the item selected
    QString data = (index.data(Qt::DisplayRole).toString());

    /// Row of the selected item
    int row = index.row();

    /// Removes the selected row from the QListWidget
    QListWidgetItem* item = ui->listWidget->takeItem(row);

    /// Removes the item from the reciept list
    reciept.remove(data);

    /// Deletes the item removed from the QListWidget
    delete item;

    /// Sets the total_label with the running total (updataed after every addition)
    ui->label_6->setText("Current Total Cost: $" + QString("%1").arg(reciept.ReturnTotal()));
}
