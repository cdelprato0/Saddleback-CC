#include "adminwindow.h"

//// Constructor
AdminWindow::AdminWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminWindow)
{
    /// Loads the window
    SetupWindow(ui);

    /// Loads and displays both databases
    LoadDatabase(ui);

    /// Set Dropdown menu items
    SetupComboBox(ui);
}

//// Destructor
AdminWindow::~AdminWindow()
{
    delete ui;
}

//// Sets the labels of the comboBox with cities thaat exist in the database.
////
//// \brief AdminWindow::SetupComboBox
//// \param ui
////
void AdminWindow::SetupComboBox(Ui::AdminWindow *ui) {
    /// Default first value
    ui->comboBox->addItem("Show All");

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->comboBox->addItem("-----------------------");
    }   /// If database can not be opened
    else{
        ui->comboBox->addItem("XXXXXXXXXXXXXXXXXXXXXXX");
    }

    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select starting_city from distanceTable group by"
                  " starting_city");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Set menu labels
    while(!places.empty()) {
        ui->comboBox->addItem(places.front());
        places.pop_front();
    }
}

//// Sets the window title and size ( Maximized )
////
//// \brief AdminWindow::SetupWindow
//// \param ui
////
void AdminWindow::SetupWindow(Ui::AdminWindow *ui) {
    ui->setupUi(this);
    this->setWindowState(Qt::WindowMaximized);
    this->setWindowTitle("Administrative Window");
}

//// Loads both databases ( food_costs & distance_table ) and displays them to
////     the tableViews.
////
//// \brief AdminWindow::LoadDatabase
//// \param ui
////
void AdminWindow::LoadDatabase(Ui::AdminWindow *ui) {
    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->label->setText("Opened database successfully");
    }   /// If database can not be opened
    else{
        ui->label->setText("Can't open database");
    }


    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select * from distanceTable");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Load Food Costs database
    QSqlQuery query2;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query2.prepare("select * from food_costs");

    /// Execute and populate QList<string> with database info
    if(query2.exec()){
        while(query2.next()){   /// Get next line
            food.push_back(query2.value(1).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query2.lastError();
    }

    /// Distance Table view
    QSqlQueryModel *distM= new QSqlQueryModel();
    distM->setQuery(query);
    ui->tableView->setModel(distM);

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query2);
    ui->tableView_2->setModel(foodM);
}

//// When clicked the AddCity window will open.
////
//// \brief AdminWindow::on_AddCities_Button_clicked
//// \param
////
void AdminWindow::on_AddCities_Button_clicked()
{
    /// Add Cities to the database
    AddCity addWin;
    addWin.setModal(true);
    addWin.exec();

}

//// When clicked the AddFood window will open.
////
//// \brief AdminWindow::on_AddFoodItem_Button_clicked
//// \param
////
void AdminWindow::on_AddFoodItem_Button_clicked()
{
    /// Add Food Item to database
    AddFood addWin;
    addWin.setModal(true);
    addWin.exec();
}

//// When clicked the RmvCity window will open.
////
//// \brief AdminWindow::on_removeCities_Button_clicked
//// \param
////
void AdminWindow::on_removeCities_Button_clicked()
{
    /// Remove Food Item from database
    RmvCity rmvWin;
    rmvWin.setModal(true);
    rmvWin.exec();
}

//// When clicked the AddCity window will open.
////
//// \brief AdminWindow::on_editCities_Button_clicked
//// \param
////
void AdminWindow::on_editCities_Button_clicked()
{
    /// Edit a Cities Food Information
    EditFood editWin;
    editWin.setModal(true);
    editWin.exec();
}

//// When clicked the AdminWindow will close and bring the user back to the mainWindow.
////
//// \brief AdminWindow::on_logOut_Button_clicked
//// \param
////
void AdminWindow::on_logOut_Button_clicked()
{
    /// Closes Admin Window
    this->close();
}

//// When clicked the tableViews will display the city selected from the comboBox
////     using a sql query.  If "Show All" is selected then all cities will be
////     displayed
////
//// \brief AdminWindow::on_pushButton_clicked
//// \param
////
void AdminWindow::on_pushButton_clicked()
{
    QString city = ui->comboBox->currentText();

    if(city == "Show All") {
        LoadDatabase(ui);
    } else {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
            ui->label->setText("Opened database successfully");
        }   /// If database can not be opened
        else{
            ui->label->setText("Can't open database");
        }


        /// Load Distance database
        QSqlQuery query;            /// SQL command to be executed (query.exec)
        QList<QString> places;      /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from distanceTable where starting_city = \""
                      + city + "\"");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){    /// Get next line
                places.push_back(query.value(0).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Load Food Costs database
        QSqlQuery query2;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query2.prepare("select * from food_costs where city = \"" + city + "\"");

        /// Execute and populate QList<string> with database info
        if(query2.exec()){
            while(query2.next()){   /// Get next line
                food.push_back(query2.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query2.lastError();
        }

        /// Distance Table view
        QSqlQueryModel *distM= new QSqlQueryModel();
        distM->setQuery(query);
        ui->tableView->setModel(distM);

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query2);
        ui->tableView_2->setModel(foodM);
    }
}


