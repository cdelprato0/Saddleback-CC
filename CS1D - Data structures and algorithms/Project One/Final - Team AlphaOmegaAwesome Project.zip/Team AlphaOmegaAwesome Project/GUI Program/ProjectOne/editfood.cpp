#include "editfood.h"
#include "ui_editfood.h"

////*****Global Variables
QString editFood;       ///Saves the data that was entered for the food name
double editCost = 0.0;  ///Saves the data that was entered for the food cost
QString editCity;       ///Saves the city that was selected from the combo box
////*****

//// Constructor
EditFood::EditFood(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EditFood)
{
    ui->setupUi(this);
    this->setWindowTitle("Edit Food Information");
    /// Load the food_cost database
    LoadFoodCostDatabase();
    /// Setup the drop down menu labels
    SetupComboBox(ui);

    ///Ensures the user does not break the program
    ui->Go_Button->setDisabled(true);
    ui->Save_Button->setDisabled(true);
    ui->FoodCost_Line->setDisabled(true);
    ui->FoodItem_Line->setDisabled(true);
}

//// Desctuctor
EditFood::~EditFood()
{
    delete ui;
}

//// Sets the labels for the comboBox from cities that exist in the database.
////
//// \brief EditFood::SetupComboBox
//// \param ui
////
void EditFood::SetupComboBox(Ui::EditFood *ui) {
    /// Default first value
    ui->comboBox->addItem("Please Select");

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->comboBox->addItem("-----------------------");
    }   /// If database can not be opened
    else{
        ui->comboBox->addItem("XXXXXXXXXXXXXXXXXXXXXXX");
    }

    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select starting_city from distanceTable group by"
                  " starting_city");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Set menu labels
    while(!places.empty()) {
        ui->comboBox->addItem(places.front());
        places.pop_front();
    }
}

//// Loads and displays the food_costs database to the tableView.
////
//// \brief EditFood::LoadFoodCostDatabase
//// \param
////
void EditFood::LoadFoodCostDatabase(){
    /// Load Food Costs database
    QSqlQuery query;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select * from food_costs");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){   /// Get next line
            food.push_back(query.value(1).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query);
    ui->tableView->setModel(foodM);
}

//// Edits the food item using a sql query.
////
//// \brief EditFood::Edit
//// \param
////
void EditFood::Edit(){
    if(ui->FoodItem_Line->text() == NULL || ui->FoodCost_Line->text() == NULL) {
        NoInput noInWin;
        noInWin.setModal(true);
        noInWin.exec();
    } else {
        const QString item = editFood;
        const QString cost = QString::number(editCost);

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("UPDATE food_costs SET cost = :fCost WHERE food = :fItem");
        query.bindValue(":fCost",cost);
        query.bindValue(":fItem", item);

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView->setModel(foodM);
    }
}

//// When clicked the Edit() function is called thus editing a food item.
////
//// \brief EditFood::on_Save_Button_clicked
//// \param
////
void EditFood::on_Save_Button_clicked(){
    Edit();
    ui->Go_Button->click();
    ui->Save_Button->setDisabled(true);
}

//// When clicked the window will close and bring the user back to the AdminWindow.
////
//// \brief EditFood::on_Done_Button_clicked
//// \param
////
void EditFood::on_Done_Button_clicked(){
    this->close();
}

//// Displays the city selected from the comboBox in the tableView using a sql query.
////
//// \brief EditFood::on_Go_Button_clicked
//// \param
////
void EditFood::on_Go_Button_clicked()
{
    QString city = editCity;

    if(city == "Please Select") {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
///            ui->label->setText("Opened database successfully");
        }   /// If database can not be opened
        else{
///            ui->label->setText("Can't open database");
        }

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from food_costs");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView->setModel(foodM);
    } else {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
            ui->label_6->setText("Opened database successfully");
        }   /// If database can not be opened
        else{
            ui->label_6->setText("Can't open database");
        }

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from food_costs where city = \"" + city + "\"");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView->setModel(foodM);

        ///Ensures the user will not break the program
        ui->FoodCost_Line->setEnabled(true);
        ui->FoodItem_Line->setEnabled(true);
    }
}

//// Ensures that the user can only input a string.
////
//// \brief EditFood::on_FoodItem_Line_textEdited
//// \param
////
void EditFood::on_FoodItem_Line_textEdited(const QString &arg1)
{
    ///Sets the regular expressions to read only characters and whitespaces
    QRegExp rx("[A-Za-z\\s]+");
    ui->FoodItem_Line->setValidator( new QRegExpValidator(rx, this));
    editFood = arg1;
}

//// Ensures that the user can only input a decimal number.
////
//// \brief EditFood::on_FoodCost_Line_textEdited
//// \param
////
void EditFood::on_FoodCost_Line_textEdited(const QString &arg1)
{
    ///Sets the input to be only numbers with a decimal point and two number allowed after
    ui->FoodCost_Line->setValidator( new QDoubleValidator(0, 999, 2, this));
    editCost = arg1.toDouble();

    ui->Save_Button->setEnabled(true);  ///enables the save button
}

//// Ensures the user cannot break the program
////
//// \brief EditFood::on_comboBox_activated
//// \param
////
void EditFood::on_comboBox_activated(const QString &arg1)
{
    ///Ensure the user does not break program
    if(arg1 != "-----------------------" && arg1 != "Please Select"){
        editCity = arg1;                ///saves the starting city the user chose
        ui->Go_Button->setEnabled(true);   ///Sets the go button
    }
}
