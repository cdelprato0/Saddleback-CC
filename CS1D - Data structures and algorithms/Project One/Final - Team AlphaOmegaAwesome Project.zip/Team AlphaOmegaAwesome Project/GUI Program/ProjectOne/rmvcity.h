#ifndef RMVCITY_H
#define RMVCITY_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "noinput.h"

namespace Ui {
class RmvCity;
}

class RmvCity : public QDialog
{
    Q_OBJECT

public:
    /// Removes a food item form the database given a city and item name
    void Remove();

    /// Sets the menu labels for drop down menu
    void SetupComboBox(Ui::RmvCity *ui);

    /// Loads and displays the food_costs to the tableView
    void LoadDatabase(Ui::RmvCity *ui);

    /// Default Constructor
    explicit RmvCity(QWidget *parent = 0);

    /// Default Destructor
    ~RmvCity();

private slots:
    void on_Save_Button_clicked();

    void on_Done_Button_clicked();

    void on_Go_Button_clicked();

    void on_CityName_Line_textEdited(const QString &arg1);

    void on_comboBox_activated(const QString &arg1);

private:
    Ui::RmvCity *ui;
};

#endif /// RMVCITY_H
