/********************************************************************************
** Form generated from reading UI file 'addfood.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDFOOD_H
#define UI_ADDFOOD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_AddFood
{
public:
    QPushButton *Done_Button;
    QPushButton *Save_Button;
    QLabel *label_2;
    QComboBox *comboBox;
    QLineEdit *FoodItem_Line;
    QLineEdit *FoodCost_Line;
    QLabel *label_3;
    QTableView *tableView_2;
    QLabel *label_4;
    QPushButton *Go_Button;
    QLabel *label_5;
    QLabel *label;
    QLabel *label_6;

    void setupUi(QDialog *AddFood)
    {
        if (AddFood->objectName().isEmpty())
            AddFood->setObjectName(QStringLiteral("AddFood"));
        AddFood->resize(579, 601);
        Done_Button = new QPushButton(AddFood);
        Done_Button->setObjectName(QStringLiteral("Done_Button"));
        Done_Button->setGeometry(QRect(460, 525, 85, 25));
        Save_Button = new QPushButton(AddFood);
        Save_Button->setObjectName(QStringLiteral("Save_Button"));
        Save_Button->setGeometry(QRect(460, 485, 85, 25));
        label_2 = new QLabel(AddFood);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 165, 81, 16));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);
        comboBox = new QComboBox(AddFood);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(40, 115, 141, 31));
        FoodItem_Line = new QLineEdit(AddFood);
        FoodItem_Line->setObjectName(QStringLiteral("FoodItem_Line"));
        FoodItem_Line->setGeometry(QRect(40, 185, 251, 31));
        FoodCost_Line = new QLineEdit(AddFood);
        FoodCost_Line->setObjectName(QStringLiteral("FoodCost_Line"));
        FoodCost_Line->setGeometry(QRect(330, 185, 70, 31));
        label_3 = new QLabel(AddFood);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(320, 165, 81, 16));
        label_3->setFont(font);
        tableView_2 = new QTableView(AddFood);
        tableView_2->setObjectName(QStringLiteral("tableView_2"));
        tableView_2->setGeometry(QRect(40, 245, 351, 300));
        label_4 = new QLabel(AddFood);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 81, 161, 20));
        label_4->setFont(font);
        Go_Button = new QPushButton(AddFood);
        Go_Button->setObjectName(QStringLiteral("Go_Button"));
        Go_Button->setGeometry(QRect(210, 115, 71, 31));
        label_5 = new QLabel(AddFood);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(140, 221, 121, 20));
        label_5->setFont(font);
        label = new QLabel(AddFood);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 550, 251, 21));
        label_6 = new QLabel(AddFood);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(140, 0, 351, 51));
        QFont font1;
        font1.setPointSize(23);
        font1.setBold(true);
        font1.setUnderline(true);
        font1.setWeight(75);
        label_6->setFont(font1);

        retranslateUi(AddFood);

        QMetaObject::connectSlotsByName(AddFood);
    } // setupUi

    void retranslateUi(QDialog *AddFood)
    {
        AddFood->setWindowTitle(QApplication::translate("AddFood", "Dialog", 0));
        Done_Button->setText(QApplication::translate("AddFood", "Close", 0));
        Save_Button->setText(QApplication::translate("AddFood", "Add", 0));
        label_2->setText(QApplication::translate("AddFood", "Food Item:", 0));
        label_3->setText(QApplication::translate("AddFood", "Food Cost:", 0));
        label_4->setText(QApplication::translate("AddFood", "Select a city to add to:", 0));
        Go_Button->setText(QApplication::translate("AddFood", "Go!", 0));
        label_5->setText(QApplication::translate("AddFood", "Food Cost Table", 0));
        label->setText(QString());
        label_6->setText(QApplication::translate("AddFood", "Adding a Menu Item", 0));
    } // retranslateUi

};

namespace Ui {
    class AddFood: public Ui_AddFood {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDFOOD_H
