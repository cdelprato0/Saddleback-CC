#include "login.h"
#include "ui_login.h"
#include "adminwindow.h"

//// Constructor
Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    this->setWindowTitle("Administrative Login");

    ui->lineEdit->setFocus();
}

//// Destructor
Login::~Login()
{
    delete ui;
}

//// When clicked the input for the password and username are validated.  If invalid
////     input is found and message will be displayed with relevent information.
////
//// \brief Login::on_buttonBox_accepted
//// \param
////
void Login::on_buttonBox_accepted()
{
    QString user = ui->lineEdit->text();    ///Reads in the input on the first line
    QString pass = ui->lineEdit_2->text();  ///Reads in the password from the second line

    ///If the user name is correct
    if( user == "admin")
    {
        ///if the password is correct, opens admin window
        if( pass == "admin")
        {
            this->hide();
            AdminWindow adminWin;
            adminWin.setModal(true);
            adminWin.exec();
        }
        else{   ///if the password is wrong
            QMessageBox::information(this, "Wrong Password",
                                    "*************************************************\n"
                                    "* You have entered the WRONG PASSWORD!  *\n"
                                    "* Please Enter the CORRECT PASSWORD!         *\n"
                                    "*************************************************\n");
            this->show();
        }
    }
    else if(user != "admin" && pass != "admin"){    ///if the username and password is wrong
        QMessageBox::information(this, "Wrong Username and Password",
                                "******************************************************************\n"
                                "* You have entered the WRONG USERNAME and PASSWORD!  *\n"
                                "* Please Enter the CORRECT USERNAME and PASSWORD!         *\n"
                                "******************************************************************\n");
        this->show();
    }
    else{   ///if the username is wrong
        QMessageBox::information(this, "Wrong Username",
                                "*************************************************\n"
                                "* You have entered the WRONG USERNAME!  *\n"
                                "* Please Enter the CORRECT USERNAME!         *\n"
                                "*************************************************\n");
        this->show();
    }

    ///Clears the slots so new input can be taken
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
}
