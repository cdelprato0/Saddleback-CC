#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "login.h"

//// Constructor
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    SetupWindow(ui);

    /// Loads and displays both databases
    LoadDatabase(ui);

    /// Set Dropdown menu items
    SetupComboBox(ui);

}

//// Destructor
MainWindow::~MainWindow()
{
    delete ui;
}

//// Sets the labels for the comboBox with cities that exist in the database.
////
//// \brief MainWindow::SetupComboBox
//// \param ui
////
void MainWindow::SetupComboBox(Ui::MainWindow *ui) {
    /// Default first value
    ui->comboBox->addItem("Show All");

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->comboBox->addItem("-----------------------");
    }   /// If database can not be opened
    else{
        ui->comboBox->addItem("XXXXXXXXXXXXXXXXXXXXXXX");
    }

    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select starting_city from distanceTable group by"
                  " starting_city");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Set menu labels
    while(!places.empty()) {
        ui->comboBox->addItem(places.front());
        places.pop_front();
    }

}

//// Sets the window title and size ( Maximized )
////
//// \brief MainWindow::SetupWindow
//// \param ui
////
void MainWindow::SetupWindow(Ui::MainWindow *ui) {
    ui->setupUi(this);
    /// Opens the main window to fullscreen mode by default
    this->setWindowState(Qt::WindowMaximized);
    /// Sets the Window title to "European Vacation Planner"
    this->setWindowTitle("European Vacation Planner");
}

//// Loads and displays the food_costs and distance_table databases to the
////     tableView.
////
//// \brief MainWindow::LoadDatabase
//// \param ui
////
void MainWindow::LoadDatabase(Ui::MainWindow *ui) {
    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->label->setText("Opened database successfully");
    }   /// If database can not be opened
    else{
        ui->label->setText("Can't open database");
    }


    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select * from distanceTable");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Load Food Costs database
    QSqlQuery query2;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query2.prepare("select * from food_costs");

    /// Execute and populate QList<string> with database info
    if(query2.exec()){
        while(query2.next()){   /// Get next line
            food.push_back(query2.value(1).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query2.lastError();
    }

    /// Distance Table view
    QSqlQueryModel *distM= new QSqlQueryModel();
    distM->setQuery(query);
    ui->tableView->setModel(distM);

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query2);
    ui->tableView_2->setModel(foodM);
}

//// Opens the Login window.
////
//// \brief MainWindow::on_actionLogin_triggered
//// \param
////
void MainWindow::on_actionLogin_triggered()
{   /// When "Login" is chosen from the adimistration drop down menu
    /// Opens the login window
    this->hide();
    Login loginWindow;
    loginWindow.setModal(true);
    loginWindow.exec();
    this->show();
}

//// Displays the city selected from the comboBox in the tableView using a sql
////     query.
////
//// \brief MainWindow::on_pushButton_clicked
//// \param
////
void MainWindow::on_pushButton_clicked()
{
    QString city = ui->comboBox->currentText();

    if(city == "Show All") {
        LoadDatabase(ui);
    } else {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
            ui->label->setText("Opened database successfully");
        }   /// If database can not be opened
        else{
            ui->label->setText("Can't open database");
        }


        /// Load Distance database
        QSqlQuery query;            /// SQL command to be executed (query.exec)
        QList<QString> places;      /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from distanceTable where starting_city = \"" +
                      city + "\"");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){    /// Get next line
                places.push_back(query.value(0).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Load Food Costs database
        QSqlQuery query2;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query2.prepare("select * from food_costs where city = \"" + city + "\"");

        /// Execute and populate QList<string> with database info
        if(query2.exec()){
            while(query2.next()){   /// Get next line
                food.push_back(query2.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query2.lastError();
        }

        /// Distance Table view
        QSqlQueryModel *distM= new QSqlQueryModel();
        distM->setQuery(query);
        ui->tableView->setModel(distM);

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query2);
        ui->tableView_2->setModel(foodM);
    }
}

//// Opens the visitAllCities Window.
////
//// \brief MainWindow::on_pushButton_2_clicked
//// \param
////
void MainWindow::on_pushButton_2_clicked()
{
    vac.show();
}

//// Opens the CustomTrip Window.
////
//// \brief MainWindow::on_pushButton_3_clicked
//// \param
////
void MainWindow::on_pushButton_3_clicked()
{
    cust.show();
}

//// Opens the ShortestTrip Window.
////
//// \brief MainWindow::on_pushButton_4_clicked
//// \param
////
void MainWindow::on_pushButton_4_clicked()
{
    shrt.show();
}
