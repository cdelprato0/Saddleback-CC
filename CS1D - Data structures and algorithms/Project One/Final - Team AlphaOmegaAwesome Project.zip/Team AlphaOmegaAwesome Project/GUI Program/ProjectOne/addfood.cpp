#include "addfood.h"
#include "ui_addfood.h"

////*****Global Variables
QString selectedCity;       ///Saves the city that was selected from the combo box
QString newItemName;        ///Saves the data that was entered for the food name
double newItemPrice = 0.0;  ///Saves the data that was entered for the food cost
////*****

//// Default Constructor
AddFood::AddFood(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddFood)
{
    ui->setupUi(this);
    this->setWindowTitle("Add a Food Item");

    SetupComboBox(ui);

    LoadFoodCostDatabase();

    ///So user will not break code
    ui->Go_Button->setDisabled(true);
    ui->Save_Button->setDisabled(true);
    ui->FoodCost_Line->setDisabled(true);
    ui->FoodItem_Line->setDisabled(true);
}

//// Destructor
AddFood::~AddFood()
{
    delete ui;
}

//// Loads the comboBox and sets the labels according to cities in the database.
////
//// \brief AddFood::SetupComboBox
//// \param ui
////
void AddFood::SetupComboBox(Ui::AddFood *ui) {
    /// Default first value
    ui->comboBox->addItem("Please Select");

    /// Setting filepath for database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("Database/euro_vac1.db");

    /// Open the database
    if(database.open()){
        ui->comboBox->addItem("-----------------------");
    }   /// If database can not be opened
    else{
        ui->comboBox->addItem("XXXXXXXXXXXXXXXXXXXXXXX");
    }

    /// Load Distance database
    QSqlQuery query;            /// SQL command to be executed (query.exec)
    QList<QString> places;      /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select starting_city from distanceTable group by"
                  " starting_city");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){    /// Get next line
            places.push_back(query.value(0).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Set menu labels
    while(!places.empty()) {
        ui->comboBox->addItem(places.front());
        places.pop_front();
    }
}

//// Loads the the food_costs database and displays it to the tableView widget.
////
//// \brief AddFood::LoadFoodCoostDatabase
//// \param
////
void AddFood::LoadFoodCostDatabase(){
    /// Load Food Costs database
    QSqlQuery query;       /// SQL command to be executed (query.exec)
    QList<QString> food;    /// Database info as a Qlist<string>

    /// SQL Command to be executed
    query.prepare("select * from food_costs");

    /// Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){   /// Get next line
            food.push_back(query.value(1).toString());
        }

    }
    else{   /// If shit happens (like it always does)
        qDebug() << query.lastError();
    }

    /// Food Table view
    QSqlQueryModel *foodM= new QSqlQueryModel();
    foodM->setQuery(query);
    ui->tableView_2->setModel(foodM);
}

//// Adds an item to the food_costs database with the given information.  The item
////     will be added using a sql query.
////
//// \brief AddFood::Add
//// \param
////
void AddFood::Add() {
    if(ui->FoodCost_Line->text() == NULL || ui->FoodItem_Line->text() == NULL) {
        NoInput noInWin;
        noInWin.setModal(true);
        noInWin.exec();
    } else {

        const QString city = selectedCity;
        const QString item = newItemName;
        const QString cost = QString::number(newItemPrice);

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("INSERT INTO food_costs (city, food, cost) values "
                      "(:cName,:fItem,:fCost)");
        query.bindValue(":cName", city);
        query.bindValue(":fCost", cost);
        query.bindValue(":fItem", item);

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView_2->setModel(foodM);
    }
}

//// When clicked the Add() function will be called and executed therefore adding
////     the given input into the database.
////
//// \brief AddFood::on_Save_Button_clicked
//// \param
////
void AddFood::on_Save_Button_clicked()
{
    Add();
    ui->Go_Button->click();
    ui->Save_Button->setDisabled(true);
}

//// When clicked the window will close and bring the user back to the admin window.
////
//// \brief AddFood::on_Done_Button_clicked
//// \param
////
void AddFood::on_Done_Button_clicked()
{
    this->close();
}

//// When clicked the tableView will be updated and display the foods and their
////     respective costs of the specified city.
////
//// \brief AddFood::on_Go_Button_clicked
//// \param
////
void AddFood::on_Go_Button_clicked()
{
    QString city = ui->comboBox->currentText();

    if(city == "Please Select") {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
///            ui->label->setText("Opened database successfully");
        }   /// If database can not be opened
        else{
///            ui->label->setText("Can't open database");
        }

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from food_costs");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView_2->setModel(foodM);
    } else {
        ///
        /// REDISPLAY TABLE VIEWS
        /// Setting filepath for database
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("Database/euro_vac1.db");

        /// Open the database
        if(database.open()){
            ui->label->setText("Opened database successfully");
        }   /// If database can not be opened
        else{
            ui->label->setText("Can't open database");
        }

        /// Load Food Costs database
        QSqlQuery query;       /// SQL command to be executed (query.exec)
        QList<QString> food;    /// Database info as a Qlist<string>

        /// SQL Command to be executed
        query.prepare("select * from food_costs where city = \"" + city + "\"");

        /// Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   /// Get next line
                food.push_back(query.value(1).toString());
            }

        }
        else{   /// If shit happens (like it always does)
            qDebug() << query.lastError();
        }

        /// Food Table view
        QSqlQueryModel *foodM= new QSqlQueryModel();
        foodM->setQuery(query);
        ui->tableView_2->setModel(foodM);

        ///Ensures that the program does not break
        ui->FoodCost_Line->setEnabled(true);
        ui->FoodItem_Line->setEnabled(true);
    }
}

//// Ensures the user cannot break the program.
////
//// \brief AddFood::on_comboBox_activated
//// \param argl
////
void AddFood::on_comboBox_activated(const QString &arg1)
{
    ///Ensure the user does not break program
    if(arg1 != "-----------------------" && arg1 != "Please Select"){
        selectedCity = arg1;        ///saves the starting city the user chose
        ui->Go_Button->setEnabled(true);   ///Sets the go button
    }
}

//// Ensures that the user can only input a decimal number.
////
//// \brief AddFood::on_FoodCost_Line_textEdited
//// \param argl
////
void AddFood::on_FoodCost_Line_textEdited(const QString &arg1)
{
    ///Sets the input to be only numbers with a decimal point and two number allowed after
    ui->FoodCost_Line->setValidator( new QDoubleValidator(0, 999, 2, this));
    newItemPrice = arg1.toDouble();

    ui->Save_Button->setEnabled(true);  ///enables the save button
}

//// Ensures that the user can only input a string.
////
//// \brief AddFood::on_FoodItem_Line_textEdited
//// \param argl
////
void AddFood::on_FoodItem_Line_textEdited(const QString &arg1)
{
    ///Sets the regular expressions to read only characters and whitespaces
    QRegExp rx("[A-Za-z\\s]+");
    ui->FoodItem_Line->setValidator( new QRegExpValidator(rx, this));
    newItemName = arg1;
}
