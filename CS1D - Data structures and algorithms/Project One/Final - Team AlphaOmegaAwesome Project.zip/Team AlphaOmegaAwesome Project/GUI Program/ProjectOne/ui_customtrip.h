/********************************************************************************
** Form generated from reading UI file 'customtrip.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUSTOMTRIP_H
#define UI_CUSTOMTRIP_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_CustomTrip
{
public:
    QLabel *label;
    QTableView *tableView;
    QListWidget *listWidget;
    QLabel *label_2;
    QComboBox *comboBox;
    QPushButton *Go;
    QLabel *label_3;
    QLabel *label_4;
    QSplitter *splitter;
    QPushButton *PlanTrip;
    QPushButton *NextCity;
    QPushButton *Close;
    QLabel *label_5;
    QTableView *Menu;
    QListWidget *Reciept;
    QLabel *label_6;

    void setupUi(QDialog *CustomTrip)
    {
        if (CustomTrip->objectName().isEmpty())
            CustomTrip->setObjectName(QStringLiteral("CustomTrip"));
        CustomTrip->resize(1031, 664);
        label = new QLabel(CustomTrip);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(90, 530, 191, 21));
        tableView = new QTableView(CustomTrip);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(80, 230, 361, 291));
        listWidget = new QListWidget(CustomTrip);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(600, 230, 351, 291));
        label_2 = new QLabel(CustomTrip);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(81, 101, 291, 23));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setUnderline(true);
        font.setWeight(75);
        label_2->setFont(font);
        comboBox = new QComboBox(CustomTrip);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(350, 98, 151, 41));
        Go = new QPushButton(CustomTrip);
        Go->setObjectName(QStringLiteral("Go"));
        Go->setGeometry(QRect(530, 100, 61, 41));
        label_3 = new QLabel(CustomTrip);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(290, 590, 441, 41));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        label_3->setFont(font1);
        label_4 = new QLabel(CustomTrip);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(300, 0, 501, 71));
        QFont font2;
        font2.setPointSize(32);
        font2.setBold(true);
        font2.setUnderline(true);
        font2.setWeight(75);
        label_4->setFont(font2);
        splitter = new QSplitter(CustomTrip);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setGeometry(QRect(460, 230, 131, 121));
        splitter->setOrientation(Qt::Vertical);
        PlanTrip = new QPushButton(splitter);
        PlanTrip->setObjectName(QStringLiteral("PlanTrip"));
        splitter->addWidget(PlanTrip);
        NextCity = new QPushButton(splitter);
        NextCity->setObjectName(QStringLiteral("NextCity"));
        splitter->addWidget(NextCity);
        Close = new QPushButton(splitter);
        Close->setObjectName(QStringLiteral("Close"));
        splitter->addWidget(Close);
        label_5 = new QLabel(CustomTrip);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(80, 180, 331, 41));
        QFont font3;
        font3.setPointSize(12);
        font3.setBold(true);
        font3.setWeight(75);
        label_5->setFont(font3);
        Menu = new QTableView(CustomTrip);
        Menu->setObjectName(QStringLiteral("Menu"));
        Menu->setGeometry(QRect(80, 230, 361, 291));
        Reciept = new QListWidget(CustomTrip);
        Reciept->setObjectName(QStringLiteral("Reciept"));
        Reciept->setGeometry(QRect(600, 230, 351, 291));
        label_6 = new QLabel(CustomTrip);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(660, 520, 261, 31));
        label_6->setFont(font1);
        Reciept->raise();
        Menu->raise();
        label->raise();
        tableView->raise();
        listWidget->raise();
        label_2->raise();
        comboBox->raise();
        Go->raise();
        label_3->raise();
        label_4->raise();
        splitter->raise();
        label_5->raise();
        label_6->raise();

        retranslateUi(CustomTrip);
        QObject::connect(PlanTrip, SIGNAL(clicked()), tableView, SLOT(hide()));
        QObject::connect(PlanTrip, SIGNAL(clicked()), listWidget, SLOT(hide()));

        QMetaObject::connectSlotsByName(CustomTrip);
    } // setupUi

    void retranslateUi(QDialog *CustomTrip)
    {
        CustomTrip->setWindowTitle(QApplication::translate("CustomTrip", "Custom Trip", 0));
        label->setText(QString());
        label_2->setText(QApplication::translate("CustomTrip", "Please select the starting city:", 0));
        Go->setText(QApplication::translate("CustomTrip", "Go", 0));
        label_3->setText(QString());
        label_4->setText(QApplication::translate("CustomTrip", "Custom European Trip", 0));
        PlanTrip->setText(QApplication::translate("CustomTrip", "Plan Trip", 0));
        NextCity->setText(QApplication::translate("CustomTrip", "Next City", 0));
        Close->setText(QApplication::translate("CustomTrip", "Close", 0));
        label_5->setText(QString());
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class CustomTrip: public Ui_CustomTrip {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUSTOMTRIP_H
