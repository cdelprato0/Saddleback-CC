#ifndef CUSTOMTRIP_H
#define CUSTOMTRIP_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "food.h"
#include "reciept.h"

namespace Ui {
class CustomTrip;
}

class CustomTrip : public QDialog
{
    Q_OBJECT

public:
    explicit CustomTrip(QWidget *parent = 0);
    ~CustomTrip();

    void ReadDatabase(Ui::CustomTrip *ui);
    void SetTable(Ui::CustomTrip *ui, QString city);
    void getAddedCityList();
    void SetupComboBox(Ui::CustomTrip *ui);

    FoodReciept reciept;    ///Used to create the reciept window

private slots:

    ///TableView, right side
    void on_tableView_doubleClicked(const QModelIndex &index);

    ///List view, left side
    void on_listWidget_doubleClicked(const QModelIndex &index);

    ///Plan Trip button
    void on_PlanTrip_clicked();

    ///Go button
    void on_Go_clicked();

    ///Next City Button
    void on_NextCity_clicked();

    ///Combo Box
    void on_comboBox_activated(const QString &arg1);

    ///Close Button
    void on_Close_clicked();

    ///Left side table view, set behind first table view
    void on_Menu_doubleClicked(const QModelIndex &index);

    ///Right side, list widget, set behind first list widget
    void on_Reciept_doubleClicked(const QModelIndex &index);

private:
    Ui::CustomTrip *ui;
};

#endif /// CUSTOMTRIP_H
