/********************************************************************************
** Form generated from reading UI file 'visitallcities.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VISITALLCITIES_H
#define UI_VISITALLCITIES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_VisitAllCities
{
public:
    QTableView *tableView;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QListWidget *listWidget;
    QLabel *label_5;
    QLabel *label_6;

    void setupUi(QDialog *VisitAllCities)
    {
        if (VisitAllCities->objectName().isEmpty())
            VisitAllCities->setObjectName(QStringLiteral("VisitAllCities"));
        VisitAllCities->resize(885, 521);
        tableView = new QTableView(VisitAllCities);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(40, 110, 381, 301));
        label = new QLabel(VisitAllCities);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 410, 231, 21));
        pushButton = new QPushButton(VisitAllCities);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(380, 440, 131, 31));
        pushButton_2 = new QPushButton(VisitAllCities);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(760, 470, 101, 31));
        label_2 = new QLabel(VisitAllCities);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 60, 641, 41));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);
        label_3 = new QLabel(VisitAllCities);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(70, 430, 211, 71));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        label_3->setFont(font1);
        label_4 = new QLabel(VisitAllCities);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(150, 0, 591, 51));
        QFont font2;
        font2.setPointSize(28);
        font2.setBold(true);
        font2.setUnderline(true);
        font2.setWeight(75);
        label_4->setFont(font2);
        listWidget = new QListWidget(VisitAllCities);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(470, 110, 381, 301));
        label_5 = new QLabel(VisitAllCities);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(630, 82, 141, 21));
        label_5->setFont(font1);
        label_6 = new QLabel(VisitAllCities);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(660, 422, 191, 21));
        label_6->setFont(font1);

        retranslateUi(VisitAllCities);

        QMetaObject::connectSlotsByName(VisitAllCities);
    } // setupUi

    void retranslateUi(QDialog *VisitAllCities)
    {
        VisitAllCities->setWindowTitle(QApplication::translate("VisitAllCities", "Visit All Cities", 0));
        label->setText(QString());
        pushButton->setText(QApplication::translate("VisitAllCities", "Next City", 0));
        pushButton_2->setText(QApplication::translate("VisitAllCities", "Close", 0));
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QApplication::translate("VisitAllCities", "Visiting All European Cities", 0));
        label_5->setText(QApplication::translate("VisitAllCities", "Reciept", 0));
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class VisitAllCities: public Ui_VisitAllCities {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VISITALLCITIES_H
