#include "noinput.h"
#include "ui_noinput.h"

//// Constructor
NoInput::NoInput(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::NoInput)
{
    ui->setupUi(this);
    this->setWindowTitle("Lacking Information!");
}

//// Destructor
NoInput::~NoInput()
{
    delete ui;
}

//// Closes the NoInput Window and brings user back to the
////     previous window.
////
//// \brief NoInput::on_Ok_Button_clicked
//// \param
////
void NoInput::on_Ok_Button_clicked()
{
    this->close();
}
