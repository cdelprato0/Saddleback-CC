/********************************************************************************
** Form generated from reading UI file 'rmvcity.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RMVCITY_H
#define UI_RMVCITY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_RmvCity
{
public:
    QLabel *label;
    QLabel *label_5;
    QTableView *tableView_2;
    QLineEdit *CityName_Line;
    QComboBox *comboBox;
    QPushButton *Go_Button;
    QLabel *label_2;
    QLabel *label_3;
    QSplitter *splitter;
    QPushButton *Save_Button;
    QPushButton *Done_Button;

    void setupUi(QDialog *RmvCity)
    {
        if (RmvCity->objectName().isEmpty())
            RmvCity->setObjectName(QStringLiteral("RmvCity"));
        RmvCity->resize(565, 599);
        label = new QLabel(RmvCity);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 160, 210, 16));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label_5 = new QLabel(RmvCity);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(150, 230, 121, 16));
        label_5->setFont(font);
        tableView_2 = new QTableView(RmvCity);
        tableView_2->setObjectName(QStringLiteral("tableView_2"));
        tableView_2->setGeometry(QRect(29, 260, 351, 300));
        CityName_Line = new QLineEdit(RmvCity);
        CityName_Line->setObjectName(QStringLiteral("CityName_Line"));
        CityName_Line->setGeometry(QRect(30, 180, 350, 31));
        comboBox = new QComboBox(RmvCity);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(30, 100, 141, 31));
        Go_Button = new QPushButton(RmvCity);
        Go_Button->setObjectName(QStringLiteral("Go_Button"));
        Go_Button->setGeometry(QRect(190, 100, 71, 31));
        label_2 = new QLabel(RmvCity);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 71, 211, 20));
        label_2->setFont(font);
        label_3 = new QLabel(RmvCity);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(120, -10, 361, 91));
        QFont font1;
        font1.setPointSize(22);
        font1.setBold(true);
        font1.setUnderline(true);
        font1.setWeight(75);
        label_3->setFont(font1);
        splitter = new QSplitter(RmvCity);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setGeometry(QRect(450, 500, 91, 61));
        splitter->setOrientation(Qt::Vertical);
        Save_Button = new QPushButton(splitter);
        Save_Button->setObjectName(QStringLiteral("Save_Button"));
        splitter->addWidget(Save_Button);
        Done_Button = new QPushButton(splitter);
        Done_Button->setObjectName(QStringLiteral("Done_Button"));
        splitter->addWidget(Done_Button);

        retranslateUi(RmvCity);

        QMetaObject::connectSlotsByName(RmvCity);
    } // setupUi

    void retranslateUi(QDialog *RmvCity)
    {
        RmvCity->setWindowTitle(QApplication::translate("RmvCity", "Dialog", 0));
        label->setText(QApplication::translate("RmvCity", "Food Item to be Removed:", 0));
        label_5->setText(QApplication::translate("RmvCity", "Food Cost Table", 0));
        Go_Button->setText(QApplication::translate("RmvCity", "Go!", 0));
        label_2->setText(QApplication::translate("RmvCity", "Select a City to Remove from:", 0));
        label_3->setText(QApplication::translate("RmvCity", "Removing a Menu Item", 0));
        Save_Button->setText(QApplication::translate("RmvCity", "Remove", 0));
        Done_Button->setText(QApplication::translate("RmvCity", "Close", 0));
    } // retranslateUi

};

namespace Ui {
    class RmvCity: public Ui_RmvCity {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RMVCITY_H
