#include "addcity.h"
#include "ui_addcity.h"

AddCity::AddCity(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddCity)
{
    ui->setupUi(this);
    this->setWindowTitle("Add a City");
    // load distance table
    LoadDistanceTable();
}

AddCity::~AddCity()
{
    delete ui;
}

void AddCity::LoadDistanceTable(){
    // Load distance table database
    QSqlQuery query;       // SQL command to be executed (query.exec)
    QList<QString> distanceTable;    // Database info as a Qlist<string>

    // SQL Command to be executed
    query.prepare("select * from distanceTable");

    // Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){   // Get next line
            distanceTable.push_back(query.value(1).toString());
        }

    }
    else{   // error
        qDebug() << query.lastError();
    }

    // Distance Table view
    QSqlQueryModel *newCity= new QSqlQueryModel();
    newCity->setQuery(query);
    ui->tableView->setModel(newCity);
}

// add starting, ending city and distance columns to table
void AddCity::Add(){
    if(ui->startCity->text() == NULL
            || ui->endCity->text() == NULL || ui->distanceCity->text() == NULL) {
        NoInput noInWin;
        noInWin.setModal(true);
        noInWin.exec();
    } else {
        const QString start = ui->startCity->text();
        const QString end = ui->endCity->text();
        const QString distance = ui->distanceCity->text();

        // Load distance table
        QSqlQuery query;       // SQL command to be executed (query.exec)
        QList<QString> distanceTable;    // Database info as a Qlist<string>

        // SQL Command to be executed
        query.prepare("INSERT INTO distanceTable (starting_city,ending_city,km) VALUES (:fstart,:fend,:fkm)");
        query.bindValue(":fstart",start);
        query.bindValue(":fend", end);
        query.bindValue(":fkm", distance);

        // Execute and populate QList<string> with database info
        if(query.exec()){
            while(query.next()){   // Get next line
                distanceTable.push_back(query.value(1).toString());
            }

        }
        else{   // error
            qDebug() << query.lastError();
        }

        // distance Table view
        QSqlQueryModel *dT= new QSqlQueryModel();
        dT->setQuery(query);
        ui->tableView->setModel(dT);
    }
}

void AddCity::on_Save_Button_clicked()
{
        this->close();
}



//Adds both Stockholm and Vienna
void AddCity::on_pushButton_2_clicked()
{
    const QList<QString> startingSt = {"Stockholm", "Stockholm", "Stockholm", "Stockholm", "Stockholm",
                               "Stockholm", "Stockholm", "Stockholm", "Stockholm", "Stockholm",
                               "Stockholm", "Stockholm"};
    const QList<QString> endingSt = {"Amsterdam", "Berlin", "Brussels", "Budapest", "Hamburg", "Lisbon",
                             "London", "Madrid", "Paris", "Prague", "Rome", "Vienna"};
    const QList<QString> kmSt = {"1435", "1084", "1564", "1951", "1079", "3610", "1902", "3141",
                           "1885", "1428", "2546", "1758"};

    const QList<QString> startingVi = {"Vienna", "Vienna", "Vienna", "Vienna", "Vienna",
                               "Vienna", "Vienna", "Vienna", "Vienna", "Vienna",
                               "Vienna", "Vienna"};
    const QList<QString> endingVi = {"Amsterdam", "Berlin", "Brussels", "Budapest", "Hamburg", "Lisbon",
                             "London", "Madrid", "Paris", "Prague", "Rome", "Stockholm"};
    const QList<QString> kmVi = {"1147", "640", "1104", "243", "930", "2867", "1461", "2401",
                           "1236", "331", "1120", "1758"};

    // Load distance table
    QSqlQuery query;       // SQL command to be executed (query.exec)
    QList<QString> distanceTable;    // Database info as a Qlist<string>


    for(int index = 0; index < startingSt.size(); index++){
        // SQL Command to be executed
        query.prepare("INSERT INTO distanceTable (starting_city,ending_city,km) VALUES (:fstart,:fend,:fkm)");
        query.bindValue(":fstart", startingSt.at(index));
        query.bindValue(":fend", endingSt.at(index));
        query.bindValue(":fkm", kmSt.at(index));
        query.exec();
    }


    for(int index = 0; index < startingVi.size(); index++){
        query.prepare("INSERT INTO distanceTable (starting_city,ending_city,km) VALUES (:fstart,:fend,:fkm)");
        query.bindValue(":fstart", startingVi.at(index));
        query.bindValue(":fend", endingVi.at(index));
        query.bindValue(":fkm", kmVi.at(index));
        query.exec();
    }

    // Execute and populate QList<string> with database info
    if(query.exec()){
        while(query.next()){   // Get next line
            distanceTable.push_back(query.value(1).toString());
        }
    }
    else{   // error
        qDebug() << query.lastError();
    }

    // distance Table view
    QSqlQueryModel *dT= new QSqlQueryModel();
    dT->setQuery(query);
    ui->tableView->setModel(dT);
}

void AddCity::on_AddCity_2_clicked()
{
    Add();
    LoadDistanceTable();
}
