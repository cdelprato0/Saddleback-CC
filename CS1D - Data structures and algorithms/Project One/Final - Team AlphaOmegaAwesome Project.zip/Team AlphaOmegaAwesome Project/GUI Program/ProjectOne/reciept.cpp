#include "reciept.h"
#include "ui_reciept.h"

//// Default Constructor
Reciept::Reciept(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Reciept)
{
    ui->setupUi(this);
    this->setWindowTitle("Your Reciept");
}

//// Overloaded Constructor
Reciept::Reciept(FoodReciept &reciept)
    : ui(new Ui::Reciept)
{
    ui->setupUi(this);
    this->setWindowTitle("Your Reciept");
    WriteReciept(reciept);
}

//// Default Destructor
Reciept::~Reciept()
{
    delete ui;
}

//// Creates a QString that will be used to set the textBroswer text.
////
//// \brief Reciept::WriteReciept
//// \param reciept
////
void Reciept::WriteReciept(FoodReciept reciept) {
    QString
        rcpt = ("                          European Vaction Planner Receipt\n\n");

    rcpt.append(reciept.Print());

    ui->textEdit->setText(rcpt);
    ui->textEdit->deleteLater();
}
