#ifndef ADDCITY_H
#define ADDCITY_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "noinput.h"

namespace Ui {
class AddCity;
}

class AddCity : public QDialog
{
    Q_OBJECT

public:

    //loads the table into the qt table view
    void LoadDistanceTable();

    // add row to table
    void Add();

    explicit AddCity(QWidget *parent = 0);

    ~AddCity();
private slots:

    //save button
    void on_Save_Button_clicked();

    void on_pushButton_2_clicked();

    void on_AddCity_2_clicked();

private:
    Ui::AddCity *ui;
};

#endif // ADDCITY_H
