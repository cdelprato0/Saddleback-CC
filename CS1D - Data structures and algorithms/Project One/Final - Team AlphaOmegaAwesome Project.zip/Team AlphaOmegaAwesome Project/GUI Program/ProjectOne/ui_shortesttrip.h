/********************************************************************************
** Form generated from reading UI file 'shortesttrip.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHORTESTTRIP_H
#define UI_SHORTESTTRIP_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ShortestTrip
{
public:
    QTableView *tableView;
    QLabel *label;
    QSpinBox *spinBox;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *PlanTrip;
    QLabel *label_4;
    QSplitter *splitter;
    QPushButton *NextCity;
    QPushButton *Close;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QListWidget *listWidget;

    void setupUi(QDialog *ShortestTrip)
    {
        if (ShortestTrip->objectName().isEmpty())
            ShortestTrip->setObjectName(QStringLiteral("ShortestTrip"));
        ShortestTrip->resize(1036, 606);
        tableView = new QTableView(ShortestTrip);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(60, 170, 391, 321));
        label = new QLabel(ShortestTrip);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 490, 191, 31));
        spinBox = new QSpinBox(ShortestTrip);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        spinBox->setGeometry(QRect(700, 90, 51, 31));
        label_2 = new QLabel(ShortestTrip);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(300, 0, 471, 71));
        QFont font;
        font.setPointSize(29);
        font.setBold(true);
        font.setUnderline(true);
        font.setWeight(75);
        label_2->setFont(font);
        label_3 = new QLabel(ShortestTrip);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 80, 601, 51));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        label_3->setFont(font1);
        PlanTrip = new QPushButton(ShortestTrip);
        PlanTrip->setObjectName(QStringLiteral("PlanTrip"));
        PlanTrip->setGeometry(QRect(820, 90, 91, 31));
        label_4 = new QLabel(ShortestTrip);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(520, 510, 341, 61));
        label_4->setFont(font1);
        splitter = new QSplitter(ShortestTrip);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setGeometry(QRect(460, 180, 111, 81));
        splitter->setOrientation(Qt::Vertical);
        NextCity = new QPushButton(splitter);
        NextCity->setObjectName(QStringLiteral("NextCity"));
        splitter->addWidget(NextCity);
        Close = new QPushButton(splitter);
        Close->setObjectName(QStringLiteral("Close"));
        splitter->addWidget(Close);
        label_5 = new QLabel(ShortestTrip);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(50, 131, 331, 31));
        QFont font2;
        font2.setPointSize(11);
        font2.setBold(true);
        font2.setWeight(75);
        label_5->setFont(font2);
        label_6 = new QLabel(ShortestTrip);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(750, 143, 91, 20));
        label_6->setFont(font1);
        label_7 = new QLabel(ShortestTrip);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(760, 490, 201, 41));
        label_7->setFont(font1);
        listWidget = new QListWidget(ShortestTrip);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(580, 170, 401, 321));

        retranslateUi(ShortestTrip);

        QMetaObject::connectSlotsByName(ShortestTrip);
    } // setupUi

    void retranslateUi(QDialog *ShortestTrip)
    {
        ShortestTrip->setWindowTitle(QApplication::translate("ShortestTrip", "Shortest Trip", 0));
        label->setText(QString());
        label_2->setText(QApplication::translate("ShortestTrip", "Shortest European Trip", 0));
        label_3->setText(QApplication::translate("ShortestTrip", "Starting from Paris, Please select the number of European Cities you would like to travel to:", 0));
        PlanTrip->setText(QApplication::translate("ShortestTrip", "Plan Trip", 0));
        label_4->setText(QString());
        NextCity->setText(QApplication::translate("ShortestTrip", "Next City", 0));
        Close->setText(QApplication::translate("ShortestTrip", "Close", 0));
        label_5->setText(QString());
        label_6->setText(QApplication::translate("ShortestTrip", "Reciept:", 0));
        label_7->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ShortestTrip: public Ui_ShortestTrip {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHORTESTTRIP_H
