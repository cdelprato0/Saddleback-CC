/********************************************************************************
** Form generated from reading UI file 'addcity.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDCITY_H
#define UI_ADDCITY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_AddCity
{
public:
    QPushButton *Save_Button;
    QLabel *label;
    QLineEdit *distanceCity;
    QLineEdit *endCity;
    QPushButton *AddCity_2;
    QLabel *label_2;
    QTableView *tableView;
    QLineEdit *startCity;
    QPushButton *pushButton_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;

    void setupUi(QDialog *AddCity)
    {
        if (AddCity->objectName().isEmpty())
            AddCity->setObjectName(QStringLiteral("AddCity"));
        AddCity->resize(613, 626);
        Save_Button = new QPushButton(AddCity);
        Save_Button->setObjectName(QStringLiteral("Save_Button"));
        Save_Button->setGeometry(QRect(90, 570, 85, 25));
        label = new QLabel(AddCity);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 100, 141, 21));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        distanceCity = new QLineEdit(AddCity);
        distanceCity->setObjectName(QStringLiteral("distanceCity"));
        distanceCity->setGeometry(QRect(52, 219, 181, 31));
        endCity = new QLineEdit(AddCity);
        endCity->setObjectName(QStringLiteral("endCity"));
        endCity->setGeometry(QRect(320, 130, 181, 31));
        AddCity_2 = new QPushButton(AddCity);
        AddCity_2->setObjectName(QStringLiteral("AddCity_2"));
        AddCity_2->setGeometry(QRect(100, 280, 75, 23));
        label_2 = new QLabel(AddCity);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(320, 100, 91, 20));
        label_2->setFont(font);
        tableView = new QTableView(AddCity);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(280, 270, 301, 311));
        startCity = new QLineEdit(AddCity);
        startCity->setObjectName(QStringLiteral("startCity"));
        startCity->setGeometry(QRect(50, 130, 181, 31));
        pushButton_2 = new QPushButton(AddCity);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(60, 430, 151, 71));
        label_3 = new QLabel(AddCity);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 190, 181, 21));
        label_3->setFont(font);
        label_4 = new QLabel(AddCity);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(360, 240, 181, 21));
        label_4->setFont(font);
        label_5 = new QLabel(AddCity);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(110, 350, 71, 41));
        QFont font1;
        font1.setPointSize(22);
        font1.setBold(true);
        font1.setUnderline(true);
        font1.setWeight(75);
        label_5->setFont(font1);
        label_6 = new QLabel(AddCity);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(190, 0, 291, 91));
        QFont font2;
        font2.setPointSize(28);
        font2.setBold(true);
        font2.setUnderline(true);
        font2.setWeight(75);
        label_6->setFont(font2);

        retranslateUi(AddCity);

        QMetaObject::connectSlotsByName(AddCity);
    } // setupUi

    void retranslateUi(QDialog *AddCity)
    {
        AddCity->setWindowTitle(QApplication::translate("AddCity", "Dialog", 0));
        Save_Button->setText(QApplication::translate("AddCity", "Save", 0));
        label->setText(QApplication::translate("AddCity", "New City:", 0));
        AddCity_2->setText(QApplication::translate("AddCity", "Add City", 0));
        label_2->setText(QApplication::translate("AddCity", "Ending City:", 0));
        pushButton_2->setText(QApplication::translate("AddCity", "Add Stockholm and Vienna", 0));
        label_3->setText(QApplication::translate("AddCity", "Distance to Ending City:", 0));
        label_4->setText(QApplication::translate("AddCity", "City and Distance Table", 0));
        label_5->setText(QApplication::translate("AddCity", "OR", 0));
        label_6->setText(QApplication::translate("AddCity", "Adding a City", 0));
    } // retranslateUi

};

namespace Ui {
    class AddCity: public Ui_AddCity {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDCITY_H
