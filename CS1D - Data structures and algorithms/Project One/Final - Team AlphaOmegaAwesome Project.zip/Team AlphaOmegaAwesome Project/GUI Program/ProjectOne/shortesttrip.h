#ifndef SHORTESTTRIP_H
#define SHORTESTTRIP_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include "food.h"
#include "reciept.h"

namespace Ui {
class ShortestTrip;
}

class ShortestTrip : public QDialog
{
    Q_OBJECT

public:
    explicit ShortestTrip(QWidget *parent = 0);
    ~ShortestTrip();

    void ReadDatabase(Ui::ShortestTrip *ui);
    void SetTable(Ui::ShortestTrip *ui, QString city);

    FoodReciept reciept;    ///Used to create reciept window

private slots:
    ///Plan Trip button
    void on_PlanTrip_clicked();

    ///Next City Button
    void on_NextCity_clicked();

    ///Spin box
    void on_spinBox_valueChanged(int arg1);

    ///Close button
    void on_Close_clicked();

    ///Left side table view
    void on_tableView_doubleClicked(const QModelIndex &index);

    ///Right side list widget
    void on_listWidget_doubleClicked(const QModelIndex &index);

private:
    Ui::ShortestTrip *ui;
};

#endif /// SHORTESTTRIP_H
