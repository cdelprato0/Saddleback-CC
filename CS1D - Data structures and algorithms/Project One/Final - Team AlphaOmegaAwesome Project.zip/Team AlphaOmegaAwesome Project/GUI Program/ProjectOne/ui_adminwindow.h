/********************************************************************************
** Form generated from reading UI file 'adminwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINWINDOW_H
#define UI_ADMINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_AdminWindow
{
public:
    QTableView *tableView;
    QTableView *tableView_2;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label;
    QPushButton *AddCities_Button;
    QPushButton *removeCities_Button;
    QPushButton *editCities_Button;
    QLabel *label_4;
    QPushButton *logOut_Button;
    QComboBox *comboBox;
    QPushButton *pushButton;
    QPushButton *AddFoodItem_Button;

    void setupUi(QDialog *AdminWindow)
    {
        if (AdminWindow->objectName().isEmpty())
            AdminWindow->setObjectName(QStringLiteral("AdminWindow"));
        AdminWindow->resize(1366, 768);
        tableView = new QTableView(AdminWindow);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(610, 70, 360, 501));
        tableView_2 = new QTableView(AdminWindow);
        tableView_2->setObjectName(QStringLiteral("tableView_2"));
        tableView_2->setGeometry(QRect(990, 70, 360, 501));
        label_2 = new QLabel(AdminWindow);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(660, 30, 261, 31));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);
        label_3 = new QLabel(AdminWindow);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(1070, 30, 261, 31));
        label_3->setFont(font);
        label = new QLabel(AdminWindow);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(920, 570, 301, 61));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        AddCities_Button = new QPushButton(AdminWindow);
        AddCities_Button->setObjectName(QStringLiteral("AddCities_Button"));
        AddCities_Button->setGeometry(QRect(50, 40, 481, 41));
        removeCities_Button = new QPushButton(AdminWindow);
        removeCities_Button->setObjectName(QStringLiteral("removeCities_Button"));
        removeCities_Button->setGeometry(QRect(50, 160, 481, 41));
        editCities_Button = new QPushButton(AdminWindow);
        editCities_Button->setObjectName(QStringLiteral("editCities_Button"));
        editCities_Button->setGeometry(QRect(50, 220, 481, 41));
        label_4 = new QLabel(AdminWindow);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(20, 320, 101, 21));
        QFont font2;
        font2.setPointSize(12);
        label_4->setFont(font2);
        logOut_Button = new QPushButton(AdminWindow);
        logOut_Button->setObjectName(QStringLiteral("logOut_Button"));
        logOut_Button->setGeometry(QRect(20, 680, 141, 31));
        comboBox = new QComboBox(AdminWindow);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(50, 350, 191, 31));
        pushButton = new QPushButton(AdminWindow);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(280, 350, 101, 31));
        AddFoodItem_Button = new QPushButton(AdminWindow);
        AddFoodItem_Button->setObjectName(QStringLiteral("AddFoodItem_Button"));
        AddFoodItem_Button->setGeometry(QRect(50, 100, 481, 41));

        retranslateUi(AdminWindow);

        QMetaObject::connectSlotsByName(AdminWindow);
    } // setupUi

    void retranslateUi(QDialog *AdminWindow)
    {
        AdminWindow->setWindowTitle(QApplication::translate("AdminWindow", "Dialog", 0));
        label_2->setText(QApplication::translate("AdminWindow", "Displaying the European Cities", 0));
        label_3->setText(QApplication::translate("AdminWindow", "Displaying the Food items ", 0));
        label->setText(QApplication::translate("AdminWindow", "Database connection", 0));
        AddCities_Button->setText(QApplication::translate("AdminWindow", "Add City", 0));
        removeCities_Button->setText(QApplication::translate("AdminWindow", "Remove Food Item", 0));
        editCities_Button->setText(QApplication::translate("AdminWindow", "Edit Foods", 0));
        label_4->setText(QApplication::translate("AdminWindow", "Display Cities:", 0));
        logOut_Button->setText(QApplication::translate("AdminWindow", "Log Out", 0));
        pushButton->setText(QApplication::translate("AdminWindow", "Go!", 0));
        AddFoodItem_Button->setText(QApplication::translate("AdminWindow", "Add Food Item", 0));
    } // retranslateUi

};

namespace Ui {
    class AdminWindow: public Ui_AdminWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINWINDOW_H
