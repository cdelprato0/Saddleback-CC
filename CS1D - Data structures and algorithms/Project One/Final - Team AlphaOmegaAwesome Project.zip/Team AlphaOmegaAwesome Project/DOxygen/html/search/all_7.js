var searchData=
[
  ['insert',['insert',['../class_food_reciept.html#aa46229c5b6dfb9641724500ad5b90f81',1,'FoodReciept']]]
];
