var searchData=
[
  ['madridtotal',['MadridTotal',['../class_food_reciept.html#aa08f83a6834e4abbeeafb215726b7718',1,'FoodReciept']]],
  ['mainwindow',['MainWindow',['../class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db',1,'MainWindow']]]
];
