var searchData=
[
  ['addcity',['AddCity',['../class_add_city.html',1,'']]],
  ['addcity',['AddCity',['../class_ui_1_1_add_city.html',1,'Ui']]],
  ['addfood',['AddFood',['../class_ui_1_1_add_food.html',1,'Ui']]],
  ['addfood',['AddFood',['../class_add_food.html',1,'']]],
  ['adminwindow',['AdminWindow',['../class_admin_window.html',1,'']]],
  ['adminwindow',['AdminWindow',['../class_ui_1_1_admin_window.html',1,'Ui']]]
];
