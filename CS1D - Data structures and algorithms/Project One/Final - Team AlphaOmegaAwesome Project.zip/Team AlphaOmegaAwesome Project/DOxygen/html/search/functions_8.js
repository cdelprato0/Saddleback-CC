var searchData=
[
  ['lisbontotal',['LisbonTotal',['../class_food_reciept.html#afe3e04c23a03420a811483470a8fb681',1,'FoodReciept']]],
  ['loaddatabase',['LoadDatabase',['../class_admin_window.html#aec573a72766731059b162d858e32fe5d',1,'AdminWindow::LoadDatabase()'],['../class_main_window.html#a758acf42d23f7645f44c49785043a06d',1,'MainWindow::LoadDatabase()'],['../class_rmv_city.html#aa57cff8aaf99933701d69a65fab578d6',1,'RmvCity::LoadDatabase()']]],
  ['loadfoodcostdatabase',['LoadFoodCostDatabase',['../class_add_food.html#ae51f9a22291880b372447072633f534d',1,'AddFood::LoadFoodCostDatabase()'],['../class_edit_food.html#a6b8c81865932258d9f89130c835faf64',1,'EditFood::LoadFoodCostDatabase()']]],
  ['login',['Login',['../class_login.html#a021ebcfd29b2a30e3f5c5bbb36589381',1,'Login']]],
  ['londontotal',['LondonTotal',['../class_food_reciept.html#aa3dea264a56d45118b966809fcac8196',1,'FoodReciept']]]
];
