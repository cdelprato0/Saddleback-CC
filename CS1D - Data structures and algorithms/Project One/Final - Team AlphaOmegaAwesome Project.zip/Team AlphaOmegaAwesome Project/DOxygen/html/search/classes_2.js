var searchData=
[
  ['editcity',['EditCity',['../class_ui_1_1_edit_city.html',1,'Ui']]],
  ['editfood',['EditFood',['../class_ui_1_1_edit_food.html',1,'Ui']]],
  ['editfood',['EditFood',['../class_edit_food.html',1,'']]]
];
