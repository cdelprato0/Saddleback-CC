var searchData=
[
  ['berlintotal',['BerlinTotal',['../class_food_reciept.html#ae53cf92815a5b557037f60ddf93a6ad5',1,'FoodReciept']]],
  ['brusselstotal',['BrusselsTotal',['../class_food_reciept.html#a01a7b95d2c46f37efe04d07e0af0b4e5',1,'FoodReciept']]],
  ['budapesttotal',['BudapestTotal',['../class_food_reciept.html#a32f240fcdc19b832f909c2ca0d2aadd0',1,'FoodReciept']]]
];
