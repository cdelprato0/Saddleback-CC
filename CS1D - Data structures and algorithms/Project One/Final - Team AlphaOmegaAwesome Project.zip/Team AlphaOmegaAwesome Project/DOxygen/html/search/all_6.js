var searchData=
[
  ['hamburgtotal',['HamburgTotal',['../class_food_reciept.html#ae03bca2db238ed74bf7a5396b4e8f10c',1,'FoodReciept']]]
];
