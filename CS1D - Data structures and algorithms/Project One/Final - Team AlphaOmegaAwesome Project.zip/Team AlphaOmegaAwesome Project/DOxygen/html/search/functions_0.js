var searchData=
[
  ['add',['Add',['../class_add_food.html#ab4296157777f3385cd5aaf7c97df5efa',1,'AddFood']]],
  ['addfood',['AddFood',['../class_add_food.html#ae08cec992ba83a8cc373d864c8a07d92',1,'AddFood']]],
  ['adminwindow',['AdminWindow',['../class_admin_window.html#a9851707c3d87acec48db6db86ae04ca4',1,'AdminWindow']]],
  ['amsterdamtotal',['AmsterdamTotal',['../class_food_reciept.html#af3a1a494ef0c8aed3553d39238c7b743',1,'FoodReciept']]]
];
