var searchData=
[
  ['paristotal',['ParisTotal',['../class_food_reciept.html#ad34aa292cb8e4771ecf4527040b931fb',1,'FoodReciept']]],
  ['praguetotal',['PragueTotal',['../class_food_reciept.html#a9859b0043e7ba18c9d69bb2be510c00c',1,'FoodReciept']]],
  ['print',['Print',['../class_food_reciept.html#a8c5d46b80a3064b229507f51b767be31',1,'FoodReciept']]]
];
