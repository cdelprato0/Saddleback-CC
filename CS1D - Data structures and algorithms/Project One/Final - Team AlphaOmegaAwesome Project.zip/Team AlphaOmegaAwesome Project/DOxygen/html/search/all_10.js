var searchData=
[
  ['writereciept',['WriteReciept',['../class_reciept.html#a3b4abdac95fce87b20d4ae1f86545126',1,'Reciept']]]
];
